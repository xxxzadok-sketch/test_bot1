import os
from dotenv import load_dotenv

print("🔍 Отладка загрузки .env файла...")
print(f"📁 Текущая папка: {os.getcwd()}")
print(f"📋 Файлы в папке: {os.listdir('.')}")

# Пробуем загрузить .env
load_dotenv()

# Проверяем токен
token = os.getenv('BOT_TOKEN')
print(f"🔐 Токен из .env: {token}")

if token:
    print("✅ .env файл загружен успешно!")
else:
    print("❌ .env файл не загружен!")
    print("💡 Проверьте:")
    print("   - Файл называется .env (без расширения)")
    print("   - Файл в той же папке что и main.py")
    print("   - Содержимое: BOT_TOKEN=ваш_токен")