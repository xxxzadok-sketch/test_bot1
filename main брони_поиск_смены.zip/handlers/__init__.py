def __init__(self):
    self.conn = sqlite3.connect(DB_NAME, check_same_thread=False)
    self.create_tables()
    self.fix_booking_dates()  # Добавьте эту строку