from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler, MessageHandler, filters, CallbackQueryHandler
from config import ADMIN_IDS
from message_manager import message_manager
from menu_manager import menu_manager
from database import Database
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

# Убедитесь, что db инициализирован правильно
db = Database()

# Состояния для управления заказами (теперь не используются в ConversationHandler)
AWAITING_TABLE_NUMBER, SELECTING_CATEGORY, SELECTING_ITEMS, SELECTING_DATE_FOR_HISTORY = range(4)


def is_admin(user_id):
    return user_id in ADMIN_IDS


def format_datetime(datetime_str):
    """Форматирует дату и время для красивого отображения"""
    if not datetime_str:
        return "Неизвестно"
    try:
        if isinstance(datetime_str, str):
            dt = datetime.strptime(datetime_str, '%Y-%m-%d %H:%M:%S')
            return dt.strftime('%d.%m.%Y %H:%M')
        else:
            return str(datetime_str)
    except Exception as e:
        logger.error(f"Ошибка форматирования даты {datetime_str}: {e}")
        return str(datetime_str)


def group_items_by_category(items_data):
    """Группирует позиции по категориям из базы данных и подсчитывает общие суммы - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    categories = {
        'Кальяны': {'name': '🍁 Кальяны', 'items': {}, 'total_quantity': 0, 'total_amount': 0},
        'Чай': {'name': '🍵 Чай', 'items': {}, 'total_quantity': 0, 'total_amount': 0},
        'Коктейли': {'name': '🍹 Коктейли', 'items': {}, 'total_quantity': 0, 'total_amount': 0},
        'Напитки': {'name': '🥤 Напитки', 'items': {}, 'total_quantity': 0, 'total_amount': 0},
        'Другое': {'name': '📦 Другое', 'items': {}, 'total_quantity': 0, 'total_amount': 0}
    }

    # Получаем все позиции меню с их категориями из базы данных
    menu_items = menu_manager.get_all_items_with_categories()

    # Создаем словарь для быстрого поиска категории по названию позиции
    item_category_map = {}
    for name, price, category in menu_items:
        item_category_map[name] = category

    for item_name, quantity, total_amount in items_data:
        # Определяем категорию позиции из базы данных - ПЕРВООЧЕРЕДНО ИСПОЛЬЗУЕМ ДАННЫЕ ИЗ БАЗЫ
        category = item_category_map.get(item_name, 'Другое')

        # Если категория не найдена в базе, используем эвристику для определения
        if category == 'Другое':
            item_lower = item_name.lower()
            if any(keyword in item_lower for keyword in
                   ['кальян', 'hookah', 'calyan', 'пенсионный', 'стандарт', 'премиум', 'фруктовая', 'сигарный',
                    'парфюм']):
                category = 'Кальяны'
            elif any(keyword in item_lower for keyword in
                     ['чай', 'tea', 'chai', 'пуэр', 'габа', 'гречишный', 'медовая', 'малина', 'мята', 'наглый', 'фрукт',
                      'вишневый', 'марроканский', 'голубика', 'смородиновый', 'клубничный', 'облепиховый']):
                category = 'Чай'
            elif any(keyword in item_lower for keyword in
                     ['коктейль', 'cocktail', 'кокт', 'пробирки', 'в/кола', 'санрайз', 'лагуна', 'фиеро']):
                category = 'Коктейли'
            elif any(keyword in item_lower for keyword in
                     ['напиток', 'drink', 'сок', 'вода', 'газировка', 'кола', 'пиво', 'энергетик', 'фанта', 'спрайт']):
                category = 'Напитки'

        # Добавляем позицию в категорию
        if item_name not in categories[category]['items']:
            categories[category]['items'][item_name] = {
                'quantity': 0,
                'total_amount': 0
            }

        categories[category]['items'][item_name]['quantity'] += quantity
        categories[category]['items'][item_name]['total_amount'] += total_amount
        categories[category]['total_quantity'] += quantity
        categories[category]['total_amount'] += total_amount

    return categories


async def back_to_admin_main(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Возврат в главное меню администратора"""
    from handlers.admin_handlers import back_to_main_menu
    await back_to_main_menu(update, context)


# СИСТЕМА УПРАВЛЕНИЯ СМЕНОЙ
async def open_shift(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Открытие смены - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        return

    # Проверяем, не открыта ли уже смена
    active_orders = db.get_active_orders()
    if active_orders:
        try:
            await query.edit_message_text(
                "⚠️ Смена уже открыта! Есть активные заказы.\n\n"
                "Для закрытия смены сначала закройте все активные заказы.",
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("📋 Активные заказы", callback_data="active_orders"),
                      InlineKeyboardButton("⬅️ Назад", callback_data="back_to_order_management")]])
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение открытия смены не требует изменений")
            else:
                logger.error(f"Ошибка при открытии смены: {e}")
                await message_manager.send_message(
                    update, context,
                    "⚠️ Смена уже открыта! Есть активные заказы.\n\nДля закрытия смены сначала закройте все активные заказы.",
                    reply_markup=InlineKeyboardMarkup(
                        [[InlineKeyboardButton("📋 Активные заказы", callback_data="active_orders"),
                          InlineKeyboardButton("⬅️ Назад", callback_data="back_to_order_management")]]),
                    is_temporary=False
                )
        return

    # Создаем новую смену в базе данных с текущим месяцем
    current_month = datetime.now().strftime('%Y-%m')
    shift_number = db.create_shift(query.from_user.id, current_month)

    # Сохраняем в context для текущей сессии
    context.bot_data['shift_open'] = True
    context.bot_data['shift_number'] = shift_number
    context.bot_data['shift_month_year'] = current_month  # Добавляем месяц
    context.bot_data['shift_opened_at'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    context.bot_data['shift_admin'] = query.from_user.id

    try:
        await query.edit_message_text(
            f"✅ Смена #{shift_number} ({current_month}) открыта!\n\n"
            "Теперь вы можете создавать заказы и управлять ими.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("➕ Создать заказ", callback_data="create_order"),
                                                InlineKeyboardButton("📋 Активные заказы", callback_data="active_orders")
                                                ],
                                               [InlineKeyboardButton("📊 История заказов",
                                                                     callback_data="order_history"),
                                                InlineKeyboardButton("🔒 Закрыть смену", callback_data="close_shift")
                                                ],
                                               [InlineKeyboardButton("⬅️ Назад",
                                                                     callback_data="back_to_order_management")
                                                ]])
        )
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение открытия смены не требует изменений")
        else:
            logger.error(f"Ошибка при открытии смены: {e}")
            await message_manager.send_message(
                update, context,
                f"✅ Смена #{shift_number} ({current_month}) открыта!\n\nТеперь вы можете создавать заказы и управлять ими.",
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("➕ Создать заказ", callback_data="create_order"),
                      InlineKeyboardButton("📋 Активные заказы", callback_data="active_orders")
                      ],
                     [InlineKeyboardButton("📊 История заказов", callback_data="order_history"),
                      InlineKeyboardButton("🔒 Закрыть смену", callback_data="close_shift")
                      ],
                     [InlineKeyboardButton("⬅️ Назад", callback_data="back_to_order_management")
                      ]]),
                is_temporary=False
            )


async def close_shift(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Закрытие смены - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        return

    # Проверяем, есть ли активные заказы
    active_orders = db.get_active_orders()
    if active_orders:
        try:
            await query.edit_message_text(
                f"⚠️ Нельзя закрыть смену! Есть активные заказы: {len(active_orders)}\n\n"
                "Пожалуйста, закройте все заказы перед закрытием смены.",
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("📋 Активные заказы", callback_data="active_orders")],
                     [InlineKeyboardButton("⬅️ Назад", callback_data="back_to_order_management")]])
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение закрытия смены не требует изменений")
            else:
                logger.error(f"Ошибка при закрытии смены: {e}")
                await message_manager.send_message(
                    update, context,
                    f"⚠️ Нельзя закрыть смену! Есть активные заказы: {len(active_orders)}\n\nПожалуйста, закройте все заказы перед закрытием смены.",
                    reply_markup=InlineKeyboardMarkup(
                        [[InlineKeyboardButton("📋 Активные заказы", callback_data="active_orders")],
                         [InlineKeyboardButton("⬅️ Назад", callback_data="back_to_order_management")]]),
                    is_temporary=False
                )
        return

    shift_number = context.bot_data.get('shift_number')
    month_year = context.bot_data.get('shift_month_year')

    if not shift_number or not month_year:
        try:
            await query.edit_message_text("❌ Ошибка: данные смены не найдены.")
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение ошибки смены не требует изменений")
            else:
                logger.error(f"Ошибка при закрытии смены: {e}")
                await message_manager.send_message(
                    update, context,
                    "❌ Ошибка: данные смены не найдены.",
                    is_temporary=True
                )
        return

    # Получаем ID текущей смены
    shift = db.get_shift_by_number_and_month(shift_number, month_year)
    if not shift:
        await query.edit_message_text("❌ Смена не найдена в базе данных.")
        return

    shift_id = shift[0]

    # Получаем заказы за смену
    shift_orders = db.get_orders_by_shift_id(shift_id)

    # Правильно считаем общую сумму всех продаж
    total_sales_amount = 0
    sales_data = {}

    for order in shift_orders:
        items = menu_manager.get_order_items(order[0])
        for item in items:
            item_name = item[2]
            quantity = item[4]
            price = item[3]
            item_total_amount = price * quantity

            # Суммируем общую сумму продаж
            total_sales_amount += item_total_amount

            if item_name not in sales_data:
                sales_data[item_name] = {'quantity': 0, 'total_amount': 0}

            sales_data[item_name]['quantity'] += quantity
            sales_data[item_name]['total_amount'] += item_total_amount

    # Сохраняем статистику в базу
    db.close_shift(shift_number, month_year, total_sales_amount, len(shift_orders))
    db.save_shift_sales(shift_number, month_year, sales_data)

    # Закрываем смену в context
    context.bot_data['shift_open'] = False
    context.bot_data['shift_closed_at'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    # Формируем сообщение со статистикой
    message = (
        f"🔒 Смена #{shift_number} ({month_year}) закрыта!\n\n"
        f"📅 Открыта: {format_datetime(shift[3])}\n"
        f"📅 Закрыта: {format_datetime(context.bot_data['shift_closed_at'])}\n"
        f"💰 Сумма всех продаж: {total_sales_amount}₽\n\n"
    )

    # Добавляем все проданные позиции
    if sales_data:
        message += "📈 Продажи по позициям:\n"
        sorted_sales = sorted(sales_data.items(), key=lambda x: x[1]['total_amount'], reverse=True)
        for i, (item_name, data) in enumerate(sorted_sales, 1):
            message += f"{i}. {item_name}: {data['quantity']} шт. - {data['total_amount']}₽\n"

    message += "\nСпасибо за работу! 🏮"

    keyboard = [
        [InlineKeyboardButton("📊 История заказов", callback_data="order_history")],
        [InlineKeyboardButton("🍽️ Управление заказов", callback_data="back_to_order_management")]
    ]

    try:
        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение закрытия смены не требует изменений")
        else:
            logger.error(f"Ошибка при закрытии смены: {e}")
            await message_manager.send_message(
                update, context,
                message,
                reply_markup=InlineKeyboardMarkup(keyboard),
                is_temporary=False
            )


async def calculate_all_orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Рассчитать все активные заказы - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        return

    active_orders = db.get_active_orders()
    if not active_orders:
        await query.edit_message_text("📭 Нет активных заказов для расчета.")
        return

    total_revenue = 0
    calculated_count = 0

    # Сначала показываем сообщение о начале расчета
    await query.edit_message_text(
        f"🔄 Начинаю расчет {len(active_orders)} заказов...",
        reply_markup=None
    )

    # Рассчитываем каждый заказ
    for order in active_orders:
        order_id = order[0]
        items = menu_manager.get_order_items(order_id)

        if items and len(items) > 0:  # Проверяем что есть позиции
            try:
                total = menu_manager.calculate_order_total(order_id)
                total_revenue += total

                # Закрываем заказ напрямую через базу
                cursor = db.conn.cursor()
                cursor.execute('''
                    UPDATE orders SET status = 'closed', closed_at = ? WHERE id = ?
                ''', (db.get_moscow_time(), order_id))
                db.conn.commit()

                calculated_count += 1

                # Показываем прогресс
                if calculated_count % 3 == 0:  # Обновляем каждые 3 заказа
                    await query.edit_message_text(
                        f"🔄 Рассчитано {calculated_count}/{len(active_orders)} заказов...",
                        reply_markup=None
                    )

            except Exception as e:
                logger.error(f"Ошибка при расчете заказа {order_id}: {e}")
                continue

    # Финальное сообщение
    if calculated_count > 0:
        message = (
            f"✅ Расчет завершен!\n\n"
            f"📊 Результаты:\n"
            f"✅ Успешно: {calculated_count} заказов\n"
            f"❌ Не удалось: {len(active_orders) - calculated_count} заказов\n"
            f"💰 Общая выручка: {total_revenue}₽\n\n"
        )

        remaining_orders = db.get_active_orders()
        if remaining_orders:
            message += f"⚠️ Осталось активных заказов: {len(remaining_orders)}\n\n"
            keyboard = [
                [InlineKeyboardButton("📋 Активные заказы", callback_data="active_orders")],
                [InlineKeyboardButton("🔒 Закрыть смену", callback_data="close_shift")],
                [InlineKeyboardButton("⬅️ Назад", callback_data="back_to_order_management")]
            ]
        else:
            message += "✅ Все заказы рассчитаны! Теперь можно закрыть смену.\n\n"
            keyboard = [
                [InlineKeyboardButton("🔒 Закрыть смену", callback_data="close_shift")],
                [InlineKeyboardButton("⬅️ Назад", callback_data="back_to_order_management")]
            ]

        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )


async def show_shift_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать статус смены - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        return

    shift_open = context.bot_data.get('shift_open', False)
    active_orders = db.get_active_orders()

    if shift_open:
        shift_number = context.bot_data.get('shift_number', 'Неизвестно')
        month_year = context.bot_data.get('shift_month_year', 'Неизвестно')
        shift_opened_at = context.bot_data.get('shift_opened_at', 'Неизвестно')
        message = (
            f"🟢 Смена #{shift_number} ({month_year}) открыта\n\n"
            f"📅 Время открытия: {shift_opened_at}\n"
            f"📋 Активных заказов: {len(active_orders)}\n"
            f"👨‍💼 Администратор: ID {context.bot_data.get('shift_admin', 'Неизвестно')}"
        )
    else:
        message = "🔴 Смена закрыта\n\nДля начала работы откройте смену."

    keyboard = [
        [InlineKeyboardButton("📊 История заказов", callback_data="order_history")],
        [InlineKeyboardButton("🍽️ Управление заказами", callback_data="back_to_order_management")]
    ]

    if shift_open:
        keyboard[0].insert(0, InlineKeyboardButton("➕ Создать заказ", callback_data="create_order"))
        keyboard[0].insert(1, InlineKeyboardButton("📋 Активные заказы", callback_data="active_orders"))
        keyboard.append([InlineKeyboardButton("🔒 Закрыть смену", callback_data="close_shift")])
    else:
        keyboard.insert(0, [InlineKeyboardButton("🔓 Открыть смену", callback_data="open_shift")])

    keyboard.append([InlineKeyboardButton("⬅️ Назад", callback_data="back_to_order_management")])

    try:
        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение статуса смены не требует изменений")
        else:
            logger.error(f"Ошибка при показе статуса смены: {e}")
            await message_manager.send_message(
                update, context,
                message,
                reply_markup=InlineKeyboardMarkup(keyboard),
                is_temporary=False
            )


async def start_order_management(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Начало управления заказами с отображением статуса смены - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    if not is_admin(update.effective_user.id):
        await message_manager.send_message(update, context, "❌ У вас нет доступа к этой команде.", is_temporary=True)
        return

    await message_manager.cleanup_user_messages(context, update.effective_user.id)

    shift_open = context.bot_data.get('shift_open', False)
    active_orders = db.get_active_orders()

    if update.callback_query:
        query = update.callback_query
        await query.answer()

    if shift_open:
        # Меню когда смена открыта
        shift_number = context.bot_data.get('shift_number', 'Неизвестно')
        month_year = context.bot_data.get('shift_month_year', 'Неизвестно')
        keyboard = [
            [InlineKeyboardButton("➕ Создать заказ", callback_data="create_order")],
            [InlineKeyboardButton("📋 Активные заказы", callback_data="active_orders")],
            [InlineKeyboardButton("📊 История заказов", callback_data="order_history")],
            [InlineKeyboardButton("🔒 Закрыть смену", callback_data="close_shift")],
            [InlineKeyboardButton("⬅️ Назад", callback_data="back_to_admin")]
        ]

        shift_opened_at = context.bot_data.get('shift_opened_at', 'Неизвестно')
        message = (
            f"🍽️ Управление заказами | Смена #{shift_number} ({month_year})\n\n"
            f"🟢 Смена открыта\n"
            f"⏰ Открыта: {shift_opened_at}\n"
            f"📋 Активных заказов: {len(active_orders)}\n\n"
            "Выберите действие:"
        )
    else:
        # Меню когда смена закрыта
        keyboard = [
            [InlineKeyboardButton("🔓 Открыть смену", callback_data="open_shift")],
            [InlineKeyboardButton("📊 История заказов", callback_data="order_history")],
            [InlineKeyboardButton("⬅️ Назад", callback_data="back_to_admin")]
        ]

        message = (
            "🍽️ Управление заказами\n\n"
            "🔴 Смена закрыта\n\n"
            "Для начала работы откройте смену."
        )

    reply_markup = InlineKeyboardMarkup(keyboard)

    if update.callback_query:
        try:
            # Пытаемся редактировать сообщение
            await update.callback_query.edit_message_text(message, reply_markup=reply_markup)
        except Exception as e:
            if "Message is not modified" in str(e):
                # Если сообщение не изменилось, просто игнорируем ошибку
                logger.debug("Сообщение не требует изменений")
            else:
                # Для других ошибок показываем новое сообщение
                logger.error(f"Ошибка при редактировании сообщения: {e}")
                await message_manager.send_message(
                    update, context,
                    message,
                    reply_markup=reply_markup,
                    is_temporary=False
                )
    else:
        await message_manager.send_message(
            update, context,
            message,
            reply_markup=reply_markup,
            is_temporary=False
        )


async def handle_create_order(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка кнопки создания заказа"""
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        return

    # Проверяем, открыта ли смена
    if not context.bot_data.get('shift_open', False):
        await query.edit_message_text(
            "❌ Смена закрыта! Сначала откройте смену.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔓 Открыть смену", callback_data="open_shift"),
                                                InlineKeyboardButton("⬅️ Назад",
                                                                     callback_data="back_to_order_management")]])
        )
        return

    # Устанавливаем флаг, что ожидаем ввод номера стола
    context.user_data['expecting_table_number'] = True

    await message_manager.send_message(
        update, context,
        "Введите номер стола:",
        is_temporary=False
    )


async def handle_table_number(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка ввода номера стола"""
    if not is_admin(update.effective_user.id):
        return

    # Убираем флаг ожидания номера стола
    context.user_data.pop('expecting_table_number', None)

    try:
        table_number = int(update.message.text.strip())
        context.user_data['table_number'] = table_number

        # Проверяем, нет ли уже активного заказа на этот стол
        existing_order = db.get_active_order_by_table(table_number)
        if existing_order:
            await message_manager.send_message(
                update, context,
                f"⚠️ На столе {table_number} уже есть активный заказ.\n"
                f"Хотите добавить позиции к существующему заказу?",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("✅ Да", callback_data=f"add_to_existing_{existing_order[0]}"),
                    InlineKeyboardButton("❌ Нет", callback_data="cancel_order")
                ]]),
                is_temporary=False
            )
            return

        # Создаем новый заказ
        order_id = menu_manager.create_order(table_number, update.effective_user.id)
        context.user_data['current_order_id'] = order_id

        await message_manager.send_message(
            update, context,
            f"✅ Заказ #{order_id} создан для стола {table_number}\n\n"
            f"Выберите категорию меню:",
            reply_markup=menu_manager.get_category_keyboard(),
            is_temporary=False
        )

    except ValueError:
        await message_manager.send_message(
            update, context,
            "❌ Пожалуйста, введите корректный номер стола:",
            is_temporary=True
        )


async def handle_category_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора категории меню - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    if query.data.startswith("category_"):
        category = query.data.replace("category_", "")
        context.user_data['current_category'] = category

        try:
            await query.edit_message_text(
                f"🍽️ Категория: {category}\n\n"
                f"Выберите позицию:",
                reply_markup=menu_manager.get_items_keyboard(category)
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение выбора категории не требует изменений")
            else:
                logger.error(f"Ошибка при выборе категории: {e}")
                await message_manager.send_message(
                    update, context,
                    f"🍽️ Категория: {category}\n\nВыберите позицию:",
                    reply_markup=menu_manager.get_items_keyboard(category),
                    is_temporary=False
                )

    elif query.data == "back_to_categories":
        try:
            await query.edit_message_text(
                "Выберите категорию меню:",
                reply_markup=menu_manager.get_category_keyboard()
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение категорий не требует изменений")
            else:
                logger.error(f"Ошибка при возврате к категориям: {e}")
                await message_manager.send_message(
                    update, context,
                    "Выберите категорию меню:",
                    reply_markup=menu_manager.get_category_keyboard(),
                    is_temporary=False
                )

    elif query.data == "cancel_order":
        await cancel_order_creation(update, context)


async def handle_item_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора позиции меню - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    if query.data.startswith("item_"):
        item_name = query.data.replace("item_", "")
        order_id = context.user_data['current_order_id']

        # Добавляем позицию в заказ
        success = menu_manager.add_item_to_order(order_id, item_name)

        if success:
            item = menu_manager.get_item_by_name(item_name)
            try:
                await query.edit_message_text(
                    f"✅ Добавлено: {item_name} - {item[1]}₽\n\n"
                    f"Продолжайте выбирать позиции или нажмите 'Готово'",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("➕ Добавить еще",
                                             callback_data=f"back_to_category_{context.user_data['current_category']}"),
                        InlineKeyboardButton("✅ Готово", callback_data="finish_order")
                    ]])
                )
            except Exception as e:
                if "Message is not modified" in str(e):
                    logger.debug("Сообщение добавления позиции не требует изменений")
                else:
                    logger.error(f"Ошибка при добавлении позиции: {e}")
                    await message_manager.send_message(
                        update, context,
                        f"✅ Добавлено: {item_name} - {item[1]}₽\n\nПродолжайте выбирать позиции или нажмите 'Готово'",
                        reply_markup=InlineKeyboardMarkup([[
                            InlineKeyboardButton("➕ Добавить еще",
                                                 callback_data=f"back_to_category_{context.user_data['current_category']}"),
                            InlineKeyboardButton("✅ Готово", callback_data="finish_order")
                        ]]),
                        is_temporary=False
                    )
        else:
            try:
                await query.edit_message_text(
                    "❌ Ошибка при добавлении позиции",
                    reply_markup=menu_manager.get_category_keyboard()
                )
            except Exception as e:
                if "Message is not modified" in str(e):
                    logger.debug("Сообщение ошибки добавления не требует изменений")
                else:
                    logger.error(f"Ошибка при добавлении позиции: {e}")
                    await message_manager.send_message(
                        update, context,
                        "❌ Ошибка при добавлении позиции",
                        reply_markup=menu_manager.get_category_keyboard(),
                        is_temporary=False
                    )

    elif query.data.startswith("back_to_category_"):
        category = query.data.replace("back_to_category_", "")
        try:
            await query.edit_message_text(
                f"🍽️ Категория: {category}\n\nВыберите позицию:",
                reply_markup=menu_manager.get_items_keyboard(category)
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение возврата к категории не требует изменений")
            else:
                logger.error(f"Ошибка при возврате к категории: {e}")
                await message_manager.send_message(
                    update, context,
                    f"🍽️ Категория: {category}\n\nВыберите позицию:",
                    reply_markup=menu_manager.get_items_keyboard(category),
                    is_temporary=False
                )

    elif query.data == "back_to_categories":
        try:
            await query.edit_message_text(
                "Выберите категорию меню:",
                reply_markup=menu_manager.get_category_keyboard()
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение категорий не требует изменений")
            else:
                logger.error(f"Ошибка при возврате к категориям: {e}")
                await message_manager.send_message(
                    update, context,
                    "Выберите категорию меню:",
                    reply_markup=menu_manager.get_category_keyboard(),
                    is_temporary=False
                )

    elif query.data == "finish_order":
        await finish_order(update, context)

    elif query.data == "cancel_order":
        await cancel_order_creation(update, context)


async def finish_order(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Завершение создания заказа - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    order_id = context.user_data['current_order_id']
    table_number = context.user_data['table_number']

    # Получаем все позиции заказа
    items = menu_manager.get_order_items(order_id)
    total = menu_manager.calculate_order_total(order_id)

    message = f"✅ Заказ #{order_id} для стола {table_number} завершен!\n\n"
    message += "📋 Состав заказа:\n"
    for item in items:
        message += f"• {item[2]} - {item[3]}₽ x {item[4]} = {item[3] * item[4]}₽\n"
    message += f"\n💰 Общая сумма: {total}₽"

    try:
        await query.edit_message_text(message)
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение завершения заказа не требует изменений")
        else:
            logger.error(f"Ошибка при завершении заказа: {e}")
            await message_manager.send_message(
                update, context,
                message,
                is_temporary=False
            )

    # Очищаем данные
    context.user_data.clear()


async def cancel_order_creation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отмена создания заказа - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    if 'current_order_id' in context.user_data:
        order_id = context.user_data['current_order_id']
        # Можно добавить логику удаления заказа если нужно
        pass

    if update.callback_query:
        try:
            await update.callback_query.edit_message_text("❌ Создание заказа отменено.")
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение отмены заказа не требует изменений")
            else:
                logger.error(f"Ошибка при отмене заказа: {e}")
                await message_manager.send_message(
                    update, context,
                    "❌ Создание заказа отменено.",
                    is_temporary=True
                )
    else:
        await message_manager.send_message(
            update, context,
            "❌ Создание заказа отменено.",
            is_temporary=True
        )
    context.user_data.clear()


async def show_active_orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать активные заказы - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    active_orders = db.get_active_orders()

    if not active_orders:
        try:
            await query.edit_message_text(
                "📭 Активных заказов нет.",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("➕ Создать заказ", callback_data="create_order"),
                    InlineKeyboardButton("🔒 Закрыть смену", callback_data="close_shift")
                ], [
                    InlineKeyboardButton("⬅️ Назад", callback_data="back_to_order_management")
                ]])
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение активных заказов не требует изменений")
            else:
                logger.error(f"Ошибка при показе активных заказов: {e}")
                await message_manager.send_message(
                    update, context,
                    "📭 Активных заказов нет.",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("➕ Создать заказ", callback_data="create_order"),
                        InlineKeyboardButton("🔒 Закрыть смену", callback_data="close_shift")
                    ], [
                        InlineKeyboardButton("⬅️ Назад", callback_data="back_to_order_management")
                    ]]),
                    is_temporary=False
                )
        return

    for order in active_orders:
        items = menu_manager.get_order_items(order[0])
        total = menu_manager.calculate_order_total(order[0])

        # Формируем информацию об администраторе
        admin_name = f"{order[5]} {order[6]}" if order[5] and order[6] else "Неизвестный администратор"

        message = f"📋 Заказ #{order[0]} | Стол {order[1]}\n"
        message += f"👨‍💼 Админ: {admin_name}\n"
        message += f"💰 Сумма: {total}₽\n"
        message += f"📅 Создан: {format_datetime(order[4])}\n"

        # Добавляем информацию о позициях если они есть
        if items:
            message += "\n🛒 Позиции:\n"
            for item in items[:3]:  # Показываем первые 3 позиции
                message += f"• {item[2]} x{item[4]}\n"
            if len(items) > 3:
                message += f"• ... и еще {len(items) - 3} позиций\n"

        # Кнопки для управления заказом
        keyboard = [
            [InlineKeyboardButton("➕ Добавить позиции", callback_data=f"add_items_{order[0]}")],
            [InlineKeyboardButton("👀 Просмотреть детали", callback_data=f"view_order_{order[0]}")],
            [InlineKeyboardButton("💰 Рассчитать", callback_data=f"calculate_{order[0]}")]
        ]

        await message_manager.send_message(
            update, context,
            message,
            reply_markup=InlineKeyboardMarkup(keyboard),
            is_temporary=False
        )

    # ИСПРАВЛЕННАЯ КЛАВИАТУРА - убрана кнопка "Рассчитать все заказы"
    await message_manager.send_message(
        update, context,
        f"📊 Всего активных заказов: {len(active_orders)}",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("🔒 Закрыть смену", callback_data="close_shift")
        ], [
            InlineKeyboardButton("➕ Создать заказ", callback_data="create_order"),
            InlineKeyboardButton("⬅️ Назад", callback_data="back_to_order_management")
        ]]),
        is_temporary=False
    )


async def show_active_orders_for_calculation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать активные заказы для расчета"""
    query = update.callback_query
    await query.answer()

    active_orders = db.get_active_orders()

    if not active_orders:
        await query.edit_message_text("📭 Активных заказов для расчета нет.")
        return

    keyboard = []
    for order in active_orders:
        total = menu_manager.calculate_order_total(order[0])
        keyboard.append([InlineKeyboardButton(
            f"Стол {order[1]} - {total}₽ (Заказ #{order[0]})",
            callback_data=f"calculate_{order[0]}"
        )])

    keyboard.append([InlineKeyboardButton("💰 Рассчитать все", callback_data="calculate_all_orders")])
    keyboard.append([InlineKeyboardButton("❌ Отмена", callback_data="cancel_calculation")])

    await query.edit_message_text(
        "Выберите заказ для расчета:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )


async def calculate_order(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Рассчитать и закрыть заказ - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    try:
        order_id = int(query.data.replace("calculate_", ""))
    except ValueError:
        try:
            await query.edit_message_text("❌ Неверный ID заказа.")
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение ошибки ID не требует изменений")
            else:
                logger.error(f"Ошибка при расчете заказа: {e}")
                await message_manager.send_message(
                    update, context,
                    "❌ Неверный ID заказа.",
                    is_temporary=True
                )
        return

    order = db.get_order_by_id(order_id)
    if not order:
        try:
            await query.edit_message_text("❌ Заказ не найден.")
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение ошибки заказа не требует изменений")
            else:
                logger.error(f"Ошибка при расчете заказа: {e}")
                await message_manager.send_message(
                    update, context,
                    "❌ Заказ не найден.",
                    is_temporary=True
                )
        return

    items = menu_manager.get_order_items(order_id)
    total = menu_manager.calculate_order_total(order_id)

    if not items:
        try:
            await query.edit_message_text("❌ В заказе нет позиций.")
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение ошибки позиций не требует изменений")
            else:
                logger.error(f"Ошибка при расчете заказа: {e}")
                await message_manager.send_message(
                    update, context,
                    "❌ В заказе нет позиций.",
                    is_temporary=True
                )
        return

    # Формируем детализированный чек
    message = f"🧾 Чек для стола {order[1]}\n"
    message += f"🆔 Заказ #{order_id}\n"
    message += f"📅 Время: {format_datetime(order[4])}\n\n"
    message += "📋 Позиции:\n"

    for item in items:
        item_total = item[3] * item[4]
        message += f"• {item[2]} - {item[3]}₽ x {item[4]} = {item_total}₽\n"

    message += f"\n💰 Итого: {total}₽\n"
    message += f"💵 К оплате: {total}₽\n\n"
    message += "✅ Заказ рассчитан и закрыт!\n"
    message += "Спасибо за посещение! 🏮"

    # Закрываем заказ
    menu_manager.close_order(order_id)

    # Всегда отправляем новое сообщение вместо редактирования
    await query.message.reply_text(message)

    # Удаляем старое сообщение с кнопками (опционально)
    try:
        await query.message.delete()
    except:
        pass  # Игнорируем ошибки удаления


async def add_items_to_existing_order(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Добавление позиций к существующему заказу"""
    query = update.callback_query
    await query.answer()

    order_id = int(query.data.replace("add_to_existing_", ""))
    context.user_data['current_order_id'] = order_id

    order = db.get_order_by_id(order_id)
    context.user_data['table_number'] = order[1]

    await query.edit_message_text(
        f"✅ Добавление к заказу #{order_id} для стола {order[1]}\n\n"
        f"Выберите категорию меню:",
        reply_markup=menu_manager.get_category_keyboard()
    )


# НОВАЯ ФУНКЦИЯ: Редактирование заказа
async def show_order_for_editing(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать заказ для редактирования (удаления позиций)"""
    query = update.callback_query
    await query.answer()

    # Правильно извлекаем order_id из callback_data
    if query.data.startswith("edit_order_"):
        order_id = int(query.data.replace("edit_order_", ""))
    elif query.data.startswith("remove_item_"):
        # Если вызываем из remove_item, берем order_id из context или из данных
        parts = query.data.split("_")
        if len(parts) >= 3:
            order_id = int(parts[2])
        else:
            await query.edit_message_text("❌ Ошибка: неверный формат данных.")
            return
    else:
        await query.edit_message_text("❌ Ошибка: неизвестная команда.")
        return

    order = db.get_order_by_id(order_id)
    if not order:
        await query.edit_message_text("❌ Заказ не найден.")
        return

    items = menu_manager.get_order_items(order_id)
    total = menu_manager.calculate_order_total(order_id)

    message = f"✏️ Редактирование заказа #{order_id}\n"
    message += f"🍽️ Стол: {order[1]}\n"
    message += f"💰 Текущая сумма: {total}₽\n\n"

    if not items:
        message += "🛒 В заказе нет позиций\n"
    else:
        message += "🛒 Позиции (нажмите чтобы удалить):\n"

    keyboard = []
    for item in items:
        item_total = item[3] * item[4]
        keyboard.append([InlineKeyboardButton(
            f"❌ {item[2]} - {item[3]}₽ x {item[4]} = {item_total}₽",
            callback_data=f"remove_item_{order_id}_{item[2].replace(' ', '_')}"  # Заменяем пробелы на подчеркивания
        )])

    keyboard.append([InlineKeyboardButton("➕ Добавить позиции", callback_data=f"add_items_{order_id}")])
    keyboard.append([InlineKeyboardButton("⬅️ Назад к заказу", callback_data=f"view_order_{order_id}")])
    keyboard.append([InlineKeyboardButton("📋 К списку заказов", callback_data="active_orders")])

    try:
        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except Exception as e:
        logger.error(f"Ошибка при показе заказа для редактирования: {e}")
        await message_manager.send_message(
            update, context,
            message,
            reply_markup=InlineKeyboardMarkup(keyboard),
            is_temporary=False
        )


async def remove_item_from_order(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Удалить позицию из заказа"""
    query = update.callback_query
    await query.answer()

    # Формат: remove_item_{order_id}_{item_name}
    parts = query.data.split("_")
    if len(parts) < 4:
        await query.edit_message_text("❌ Ошибка в данных запроса.")
        return

    order_id = int(parts[2])
    item_name = "_".join(parts[3:])  # Название может содержать подчеркивания

    # Заменяем обратно подчеркивания на пробелы в названии товара
    item_name = item_name.replace('_', ' ')

    # Удаляем позицию
    success, message = menu_manager.remove_item_from_order(order_id, item_name)

    if success:
        # Показываем обновленный заказ
        await show_order_for_editing(update, context)
    else:
        await query.edit_message_text(
            f"❌ {message}",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("⬅️ Назад", callback_data=f"edit_order_{order_id}")
            ]])
        )


async def view_order_details(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Просмотр деталей заказа - ОБНОВЛЕННАЯ ВЕРСИЯ С КНОПКОЙ РЕДАКТИРОВАНИЯ"""
    query = update.callback_query
    await query.answer()

    order_id = int(query.data.replace("view_order_", ""))
    order = db.get_order_by_id(order_id)
    items = menu_manager.get_order_items(order_id)
    total = menu_manager.calculate_order_total(order_id)

    message = f"📋 Детали заказа #{order_id}\n"
    message += f"🍽️ Стол: {order[1]}\n"
    message += f"📅 Создан: {format_datetime(order[4])}\n"
    message += f"📊 Статус: {order[3]}\n\n"
    message += "🛒 Позиции:\n"

    for item in items:
        item_total = item[3] * item[4]
        message += f"• {item[2]} - {item[3]}₽ x {item[4]} = {item_total}₽\n"

    message += f"\n💰 Общая сумма: {total}₽"

    # ОБНОВЛЕННАЯ КЛАВИАТУРА - добавлена кнопка редактирования
    keyboard = [
        [InlineKeyboardButton("✏️ Редактировать заказ", callback_data=f"edit_order_{order_id}")],
        [InlineKeyboardButton("➕ Добавить позиции", callback_data=f"add_items_{order_id}")],
        [InlineKeyboardButton("💰 Рассчитать", callback_data=f"calculate_{order_id}")],
        [InlineKeyboardButton("⬅️ Назад к заказам", callback_data="active_orders")]
    ]

    try:
        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение деталей заказа не требует изменений")
        else:
            logger.error(f"Ошибка при просмотре деталей заказа: {e}")
            await message_manager.send_message(
                update, context,
                message,
                reply_markup=InlineKeyboardMarkup(keyboard),
                is_temporary=False
            )


async def handle_add_items(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка кнопки добавления позиций"""
    query = update.callback_query
    await query.answer()

    order_id = int(query.data.replace("add_items_", ""))
    context.user_data['current_order_id'] = order_id

    order = db.get_order_by_id(order_id)
    context.user_data['table_number'] = order[1]

    await query.edit_message_text(
        f"✅ Добавление позиций к заказу #{order_id} для стола {order[1]}\n\n"
        f"Выберите категорию меню:",
        reply_markup=menu_manager.get_category_keyboard()
    )


async def handle_cancel_calculation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отмена расчета заказа - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    try:
        await query.edit_message_text("❌ Расчет заказа отменен.")
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение отмены расчета не требует изменений")
        else:
            logger.error(f"Ошибка при отмене расчета: {e}")
            await message_manager.send_message(
                update, context,
                "❌ Расчет заказа отменен.",
                is_temporary=True
            )


async def handle_back_to_orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Возврат к списку заказов"""
    query = update.callback_query
    await query.answer()

    await show_active_orders(update, context)


# ИСТОРИЯ ЗАКАЗОВ - ОБНОВЛЕННАЯ ВЕРСИЯ
async def show_order_history_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать меню истории заказов - ОБНОВЛЕННАЯ ВЕРСИЯ БЕЗ КНОПКИ 'ЗА МЕСЯЦ'"""
    query = update.callback_query
    await query.answer()

    keyboard = [
        [InlineKeyboardButton("🔄 За смену", callback_data="history_shift")],
        [InlineKeyboardButton("📅 Выбрать смену", callback_data="history_select_shift")],
        [InlineKeyboardButton("📊 За год", callback_data="history_year")],  # Убедитесь что здесь history_year
        [InlineKeyboardButton("⬅️ Назад", callback_data="back_to_order_management")]
    ]

    try:
        await query.edit_message_text(
            "📊 История заказов\n\n"
            "Выберите период для просмотра:",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение истории заказов не требует изменений")
        else:
            logger.error(f"Ошибка при показе меню истории заказов: {e}")
            await message_manager.send_message(
                update, context,
                "📊 История заказов\n\nВыберите период для просмотра:",
                reply_markup=InlineKeyboardMarkup(keyboard),
                is_temporary=False
            )


async def show_shift_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать историю за текущую смену - ОБНОВЛЕННАЯ ВЕРСИЯ С ПОДРОБНОЙ ИНФОРМАЦИЕЙ О ЗАКАЗАХ И БОНУСАХ"""
    query = update.callback_query
    await query.answer()

    shift_number = context.bot_data.get('shift_number')
    month_year = context.bot_data.get('shift_month_year')

    if not shift_number or not month_year:
        try:
            await query.edit_message_text(
                "❌ Нет активной смены.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data="order_history")]])
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение ошибки смены не требует изменений")
            else:
                logger.error(f"Ошибка при показе истории смены: {e}")
                await message_manager.send_message(
                    update, context,
                    "❌ Нет активной смены.",
                    reply_markup=InlineKeyboardMarkup(
                        [[InlineKeyboardButton("⬅️ Назад", callback_data="order_history")]]),
                    is_temporary=False
                )
        return

    # Получаем ID текущей смены
    shift = db.get_shift_by_number_and_month(shift_number, month_year)
    if not shift:
        try:
            await query.edit_message_text(
                f"📭 Смена #{shift_number} ({month_year}) не найдена.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data="order_history")]])
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение отсутствия данных не требует изменений")
            else:
                logger.error(f"Ошибка при показе истории смены: {e}")
                await message_manager.send_message(
                    update, context,
                    f"📭 Смена #{shift_number} ({month_year}) не найдена.",
                    reply_markup=InlineKeyboardMarkup(
                        [[InlineKeyboardButton("⬅️ Назад", callback_data="order_history")]]),
                    is_temporary=False
                )
        return

    shift_id = shift[0]

    # Получаем все заказы текущей смены (активные и закрытые)
    shift_orders = db.get_orders_by_shift_id(shift_id)

    if not shift_orders:
        try:
            await query.edit_message_text(
                f"📭 Нет заказов за текущую смену #{shift_number} ({month_year}).",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data="order_history")]])
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение отсутствия данных не требует изменений")
            else:
                logger.error(f"Ошибка при показе истории смены: {e}")
                await message_manager.send_message(
                    update, context,
                    f"📭 Нет заказов за текущую смену #{shift_number} ({month_year}).",
                    reply_markup=InlineKeyboardMarkup(
                        [[InlineKeyboardButton("⬅️ Назад", callback_data="order_history")]]),
                    is_temporary=False
                )
        return

    # Формируем подробный отчет по смене
    total_revenue = 0
    active_orders_count = 0
    closed_orders_count = 0

    message = f"📊 Текущая смена #{shift_number} ({month_year})\n\n"
    message += f"📅 Открыта: {format_datetime(shift[3])}\n"
    message += f"📋 Всего заказов: {len(shift_orders)}\n\n"

    # Получаем сумму списанных бонусов за смену
    spent_bonuses = db.get_spent_bonuses_by_shift(shift_number, month_year)

    # Обрабатываем каждый заказ
    for order in shift_orders:
        order_id = order[0]
        table_number = order[1]
        status = order[3]
        created_at = format_datetime(order[4])
        closed_at = format_datetime(order[5]) if order[5] else "Еще не закрыт"

        items = menu_manager.get_order_items(order_id)
        total = menu_manager.calculate_order_total(order_id)
        total_revenue += total

        # Считаем статистику по статусам
        if status == 'active':
            active_orders_count += 1
        elif status == 'closed':
            closed_orders_count += 1

        message += f"🧾 Заказ #{order_id} | Стол {table_number}\n"
        message += f"📊 Статус: {'🟢 Активен' if status == 'active' else '🔴 Закрыт'}\n"
        message += f"💰 Сумма: {total}₽\n"
        message += f"📅 Создан: {created_at}\n"

        if status == 'closed':
            message += f"📅 Закрыт: {closed_at}\n"

        # Добавляем информацию о позициях
        if items:
            message += "🛒 Позиции:\n"
            for item in items:
                item_total = item[3] * item[4]
                message += f"  • {item[2]} - {item[3]}₽ x {item[4]} = {item_total}₽\n"
        else:
            message += "🛒 Позиции: нет\n"

        message += "─" * 30 + "\n\n"

    # Добавляем общую статистику
    message += f"📈 Итоги смены:\n"
    message += f"🟢 Активных заказов: {active_orders_count}\n"
    message += f"🔴 Закрытых заказов: {closed_orders_count}\n"
    message += f"💰 Общая выручка: {total_revenue}₽\n"
    message += f"🎫 Сумма списанных бонусов: {spent_bonuses}₽\n\n"

    keyboard = [
        [InlineKeyboardButton("📊 Другая статистика", callback_data="order_history")],
        [InlineKeyboardButton("⬅️ Назад в управление", callback_data="back_to_order_management")]
    ]

    # Если сообщение слишком длинное, разбиваем на части
    if len(message) > 4000:
        parts = []
        current_part = ""
        lines = message.split('\n')

        for line in lines:
            if len(current_part + line + '\n') < 4000:
                current_part += line + '\n'
            else:
                parts.append(current_part)
                current_part = line + '\n'

        if current_part:
            parts.append(current_part)

        # Отправляем первую часть с клавиатурой
        await query.edit_message_text(
            parts[0],
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

        # Остальные части отправляем как новые сообщения
        for part in parts[1:]:
            await message_manager.send_message(
                update, context,
                part,
                is_temporary=False
            )
    else:
        try:
            await query.edit_message_text(
                message,
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение истории смены не требует изменений")
            else:
                logger.error(f"Ошибка при показе истории смены: {e}")
                await message_manager.send_message(
                    update, context,
                    message,
                    reply_markup=InlineKeyboardMarkup(keyboard),
                    is_temporary=False
                )


async def show_month_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать статистику за месяц - ОБНОВЛЕННАЯ ВЕРСИЯ С ГРУППИРОВКОЙ И БОНУСАМИ"""
    query = update.callback_query
    await query.answer()

    # Получаем статистику за месяц
    sales_stats = db.get_sales_statistics_by_period('month')
    total_revenue = db.get_total_revenue_by_period('month')

    if not sales_stats:
        try:
            await query.edit_message_text(
                "📭 Нет данных за текущий месяц.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data="order_history")]])
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение отсутствия данных не требует изменений")
            else:
                logger.error(f"Ошибка при показе статистики месяца: {e}")
                await message_manager.send_message(
                    update, context,
                    "📭 Нет данных за текущий месяц.",
                    reply_markup=InlineKeyboardMarkup(
                        [[InlineKeyboardButton("⬅️ Назад", callback_data="order_history")]]),
                    is_temporary=False
                )
        return

    current_month = datetime.now().strftime('%B %Y')
    # Считаем общую сумму всех продаж
    total_sales_amount = sum(total_amount for _, _, total_amount in sales_stats)

    # Получаем сумму списанных бонусов за текущий месяц
    current_date = datetime.now()
    spent_bonuses = db.get_spent_bonuses_by_month(current_date.year, current_date.month)

    # Группируем позиции по категориям - ОБНОВЛЕННАЯ ФУНКЦИЯ
    categories = group_items_by_category(sales_stats)

    message = f"📊 Статистика за {current_month}\n\n"
    message += f"💰 Общая сумма продаж: {total_sales_amount}₽\n"
    message += f"🎫 Сумма списанных бонусов: {spent_bonuses}₽\n\n"
    message += "📈 Продажи по категориям:\n\n"

    # Выводим категории с группировкой
    for category_key in ['Кальяны', 'Чай', 'Коктейли', 'Напитки', 'Другое']:
        category_data = categories[category_key]
        if category_data['total_quantity'] > 0:
            message += f"{category_data['name']}:\n"
            message += f"  Всего: {category_data['total_quantity']} шт. - {category_data['total_amount']}₽\n"

            # Выводим детали по позициям внутри категории
            for item_name, item_data in category_data['items'].items():
                message += f"  • {item_name}: {item_data['quantity']} шт. - {item_data['total_amount']}₽\n"
            message += "\n"

    keyboard = [
        [InlineKeyboardButton("📊 Другая статистика", callback_data="order_history")],
        [InlineKeyboardButton("⬅️ Назад в управление", callback_data="back_to_order_management")]
    ]

    try:
        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение статистики месяца не требует изменений")
        else:
            logger.error(f"Ошибка при показе статистики месяца: {e}")
            await message_manager.send_message(
                update, context,
                message,
                reply_markup=InlineKeyboardMarkup(keyboard),
                is_temporary=False
            )


async def show_year_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать меню выбора года для статистики - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    # ИСПРАВЛЕННЫЙ ВЫЗОВ - через экземпляр db
    years = db.get_shift_years()

    if not years:
        try:
            await query.edit_message_text(
                "📭 Нет данных за предыдущие годы.\n\n"
                "Данные появятся после закрытия первой смены.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data="order_history")]])
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение отсутствия данных не требует изменений")
            else:
                logger.error(f"Ошибка при показе статистики года: {e}")
                await message_manager.send_message(
                    update, context,
                    "📭 Нет данных за предыдущие годы.\n\nДанные появятся после закрытия первой смены.",
                    reply_markup=InlineKeyboardMarkup(
                        [[InlineKeyboardButton("⬅️ Назад", callback_data="order_history")]]),
                    is_temporary=False
                )
        return

    keyboard = []
    for year in years:
        keyboard.append([InlineKeyboardButton(f"📅 {year} год", callback_data=f"history_year_{year}")])
    keyboard.append([InlineKeyboardButton("⬅️ Назад", callback_data="order_history")])

    try:
        await query.edit_message_text(
            "📊 Статистика за год\n\n"
            "Выберите год для просмотра:",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение выбора года не требует изменений")
        else:
            logger.error(f"Ошибка при показе выбора года: {e}")
            await message_manager.send_message(
                update, context,
                "📊 Статистика за год\n\nВыберите год для просмотра:",
                reply_markup=InlineKeyboardMarkup(keyboard),
                is_temporary=False
            )


async def select_year_for_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора года для статистики - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    year = query.data.replace("history_year_", "")
    context.user_data['selected_year'] = year

    # ИСПРАВЛЕННЫЙ ВЫЗОВ - через экземпляр db
    months = db.get_shift_months(year)

    if not months:
        try:
            await query.edit_message_text(
                f"📭 Нет данных за {year} год.\n\n"
                "Данные появятся после закрытия смен в этом году.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data="history_year")]])
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение отсутствия данных не требует изменений")
            else:
                logger.error(f"Ошибка при показе месяцев: {e}")
        return

    keyboard = []

    # Добавляем кнопку "За весь год"
    keyboard.append([InlineKeyboardButton(f"📊 За весь {year} год", callback_data=f"history_full_year_{year}")])
    keyboard.append([InlineKeyboardButton("─" * 20, callback_data="separator")])  # Разделитель

    month_names = {
        '01': 'Январь', '02': 'Февраль', '03': 'Март', '04': 'Апрель',
        '05': 'Май', '06': 'Июнь', '07': 'Июль', '08': 'Август',
        '09': 'Сентябрь', '10': 'Октябрь', '11': 'Ноябрь', '12': 'Декабрь'
    }

    for month in months:
        month_name = month_names.get(month, month)
        # Формируем правильный callback: history_month_2024_01
        keyboard.append([InlineKeyboardButton(f"📆 {month_name}", callback_data=f"history_month_{year}_{month}")])
    keyboard.append([InlineKeyboardButton("⬅️ Назад", callback_data="history_year")])

    try:
        await query.edit_message_text(
            f"📊 Статистика за {year} год\n\n"
            "Выберите период:",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение выбора месяца не требует изменений")
        else:
            logger.error(f"Ошибка при показе выбора месяца: {e}")
            await message_manager.send_message(
                update, context,
                f"📊 Статистика за {year} год\n\nВыберите период:",
                reply_markup=InlineKeyboardMarkup(keyboard),
                is_temporary=False
            )


async def show_full_year_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать статистику за весь год - ОБНОВЛЕННАЯ ВЕРСИЯ С ПРОВЕРКОЙ ДАННЫХ И БОНУСАМИ"""
    query = update.callback_query
    await query.answer()

    # Извлекаем год из callback_data: history_full_year_2024
    year = query.data.replace("history_full_year_", "")
    context.user_data['selected_year'] = year

    # Получаем статистику за весь год
    sales_stats = db.get_sales_statistics_by_year(year)

    if not sales_stats:
        try:
            await query.edit_message_text(
                f"📭 Нет данных за {year} год.\n\n"
                "Данные появятся после закрытия смен в этом году.",
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("⬅️ Назад", callback_data=f"history_year_{year}")]])
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение отсутствия данных не требует изменений")
            else:
                logger.error(f"Ошибка при показе статистики года: {e}")
        return

    total_revenue = db.get_total_revenue_by_year(year)

    # Получаем сумму списанных бонусов за год
    spent_bonuses = db.get_spent_bonuses_by_year(year)

    # Считаем общую сумму всех продаж
    total_sales_amount = sum(total_amount for _, _, total_amount in sales_stats)

    # Группируем позиции по категориям
    categories = group_items_by_category(sales_stats)

    message = f"📊 Статистика за {year} год\n\n"
    message += f"💰 Общая сумма продаж: {total_sales_amount}₽\n"
    message += f"🎫 Сумма списанных бонусов: {spent_bonuses}₽\n\n"

    # Проверяем, есть ли данные для отображения
    has_data = False
    for category_key in ['Кальяны', 'Чай', 'Коктейли', 'Напитки', 'Другое']:
        category_data = categories[category_key]
        if category_data['total_quantity'] > 0:
            has_data = True
            break

    if not has_data:
        message += "📭 Нет данных о продажах за этот период."
    else:
        message += "📈 Продажи по категориям:\n\n"

        # Выводим категории с группировкой
        for category_key in ['Кальяны', 'Чай', 'Коктейли', 'Напитки', 'Другое']:
            category_data = categories[category_key]
            if category_data['total_quantity'] > 0:
                message += f"{category_data['name']}:\n"
                message += f"  Всего: {category_data['total_quantity']} шт. - {category_data['total_amount']}₽\n"

                # Выводим детали по позиции внутри категории
                for item_name, item_data in category_data['items'].items():
                    message += f"  • {item_name}: {item_data['quantity']} шт. - {item_data['total_amount']}₽\n"
                message += "\n"

    keyboard = [
        [InlineKeyboardButton("📅 Выбрать месяц", callback_data=f"history_year_{year}")],
        [InlineKeyboardButton("📊 Другая статистика", callback_data="order_history")],
        [InlineKeyboardButton("⬅️ Назад в управление", callback_data="back_to_order_management")]
    ]

    try:
        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение статистики года не требует изменений")
        else:
            logger.error(f"Ошибка при показе статистики года: {e}")
            await message_manager.send_message(
                update, context,
                message,
                reply_markup=InlineKeyboardMarkup(keyboard),
                is_temporary=False
            )


# НОВАЯ ФУНКЦИЯ: Показ всех смен в месяце с пагинацией
async def select_month_for_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора месяца для статистики - ОБНОВЛЕННАЯ ВЕРСИЯ СО ВСЕМИ СМЕНАМИ"""
    query = update.callback_query
    await query.answer()

    # Правильный разбор данных: history_month_2024_01
    parts = query.data.split("_")
    if len(parts) != 4:
        try:
            await query.edit_message_text(
                "❌ Ошибка в данных запроса.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data="history_year")]])
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение ошибки не требует изменений")
            else:
                logger.error(f"Ошибка при разборе данных месяца: {e}")
        return

    year = parts[2]
    month = parts[3]
    context.user_data['selected_year'] = year
    context.user_data['selected_month'] = month

    # ИСПРАВЛЕННЫЙ ВЫЗОВ - через экземпляр db
    shifts = db.get_shifts_by_year_month(year, month)

    if not shifts:
        try:
            await query.edit_message_text(
                f"📭 Нет смен за выбранный период.",
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("⬅️ Назад", callback_data=f"history_year_{year}")]])
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение отсутствия смен не требует изменений")
            else:
                logger.error(f"Ошибка при показе смен: {e}")
        return

    month_names = {
        '01': 'Январь', '02': 'Февраль', '03': 'Март', '04': 'Апрель',
        '05': 'Май', '06': 'Июнь', '07': 'Июль', '08': 'Август',
        '09': 'Сентябрь', '10': 'Октябрь', '11': 'Ноябрь', '12': 'Декабрь'
    }
    month_name = month_names.get(month, month)

    keyboard = []

    # Добавляем кнопку "За весь месяц"
    keyboard.append(
        [InlineKeyboardButton(f"📊 Весь {month_name} {year}", callback_data=f"history_full_month_{year}_{month}")])
    keyboard.append([InlineKeyboardButton("─" * 20, callback_data="separator")])  # Разделитель

    # ПОКАЗЫВАЕМ ВСЕ СМЕНЫ (не только 10)
    for shift in shifts:
        shift_number = shift[1]
        month_year = shift[2]
        opened_at = shift[3]  # Это уже строка из базы данных

        # ИСПРАВЛЕНИЕ: Добавляем проверку типа
        if opened_at and isinstance(opened_at, str):
            opened_date = opened_at.split()[0] if ' ' in opened_at else opened_at
        else:
            # Если opened_at None или не строка, используем значение по умолчанию
            opened_date = "Неизвестно"

        revenue = shift[6] or 0
        orders_count = shift[7] or 0

        keyboard.append([InlineKeyboardButton(
            f"#{shift_number} | {opened_date} | {revenue}₽ | {orders_count} зак.",
            callback_data=f"history_shift_{month_year}_{shift_number}"  # Новый формат с месяцем и номером
        )])

    # Добавляем пагинацию если смен больше 50
    if len(shifts) > 50:
        keyboard.append(
            [InlineKeyboardButton("📄 Показать еще...", callback_data=f"history_month_more_{year}_{month}_2")])

    keyboard.append([InlineKeyboardButton("⬅️ Назад", callback_data=f"history_year_{year}")])

    try:
        await query.edit_message_text(
            f"📊 Смены за {month_name} {year} года:\n\n"
            f"📋 Найдено смен: {len(shifts)}\n"
            f"👆 Выберите смену для просмотра детальной статистики",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение списка смен не требует изменений")
        else:
            logger.error(f"Ошибка при показе списка смен: {e}")


async def show_more_shifts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать следующие смены (пагинация) - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    # Формат: history_month_more_2024_01_2
    parts = query.data.split("_")
    if len(parts) != 6:
        await query.edit_message_text("❌ Ошибка в данных запроса.")
        return

    year = parts[3]
    month = parts[4]
    page = int(parts[5])

    # ИСПРАВЛЕННЫЙ ВЫЗОВ - через экземпляр db
    shifts = db.get_shifts_by_year_month(year, month)

    if not shifts:
        await query.edit_message_text("📭 Нет смен за выбранный период.")
        return

    month_names = {
        '01': 'Январь', '02': 'Февраль', '03': 'Март', '04': 'Апрель',
        '05': 'Май', '06': 'Июнь', '07': 'Июль', '08': 'Август',
        '09': 'Сентябрь', '10': 'Октябрь', '11': 'Ноябрь', '12': 'Декабрь'
    }
    month_name = month_names.get(month, month)

    keyboard = []

    # Вычисляем диапазон для текущей страницы
    items_per_page = 50
    start_idx = (page - 1) * items_per_page
    end_idx = start_idx + items_per_page

    for shift in shifts[start_idx:end_idx]:
        shift_number = shift[1]
        month_year = shift[2]
        opened_at = shift[3]

        # ИСПРАВЛЕНИЕ: Добавляем проверку типа
        if opened_at and isinstance(opened_at, str):
            opened_date = opened_at.split()[0] if ' ' in opened_at else opened_at
        else:
            opened_date = "Неизвестно"

        revenue = shift[6] or 0
        orders_count = shift[7] or 0

        keyboard.append([InlineKeyboardButton(
            f"#{shift_number} | {opened_date} | {revenue}₽ | {orders_count} зак.",
            callback_data=f"history_shift_{month_year}_{shift_number}"  # Новый формат
        )])

    # Добавляем навигацию по страницам
    navigation = []
    if page > 1:
        navigation.append(
            InlineKeyboardButton("⬅️ Предыдущие", callback_data=f"history_month_more_{year}_{month}_{page - 1}"))

    if end_idx < len(shifts):
        navigation.append(
            InlineKeyboardButton("Следующие ➡️", callback_data=f"history_month_more_{year}_{month}_{page + 1}"))

    if navigation:
        keyboard.append(navigation)

    keyboard.append([InlineKeyboardButton("⬅️ Назад к выбору", callback_data=f"history_year_{year}")])

    await query.edit_message_text(
        f"📊 Смены за {month_name} {year} года (стр. {page}):\n\n"
        f"📋 Всего смен: {len(shifts)}\n"
        f"👆 Выберите смену для просмотра детальной статистики",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )


async def show_full_month_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать статистику за весь месяц - ОБНОВЛЕННАЯ ВЕРСИЯ С ГРУППИРОВКОЙ И БОНУСАМИ"""
    query = update.callback_query
    await query.answer()

    year = context.user_data.get('selected_year')
    month = context.user_data.get('selected_month')

    if not year or not month:
        try:
            await query.edit_message_text(
                "❌ Год или месяц не выбран.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data="history_year")]])
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение ошибки не требует изменений")
            else:
                logger.error(f"Ошибка при показе статистики месяца: {e}")
        return

    # Получаем статистику за весь месяц
    sales_stats = db.get_sales_statistics_by_year_month(year, month)
    total_revenue = db.get_total_revenue_by_year_month(year, month)

    if not sales_stats:
        try:
            await query.edit_message_text(
                f"📭 Нет данных за выбранный период.",
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("⬅️ Назад", callback_data=f"history_year_{year}")]])
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение отсутствия данных не требует изменений")
            else:
                logger.error(f"Ошибка при показе статистики месяца: {e}")
        return

    month_names = {
        '01': 'Январь', '02': 'Февраль', '03': 'Март', '04': 'Апрель',
        '05': 'Май', '06': 'Июнь', '07': 'Июль', '08': 'Август',
        '09': 'Сентябрь', '10': 'Октябрь', '11': 'Ноябрь', '12': 'Декабрь'
    }
    month_name = month_names.get(month, month)

    # Получаем сумму списанных бонусов за месяц
    spent_bonuses = db.get_spent_bonuses_by_month(year, month)

    # Считаем общую сумму всех продаж
    total_sales_amount = sum(total_amount for _, _, total_amount in sales_stats)

    # Группируем позиции по категориям - ОБНОВЛЕННАЯ ФУНКЦИЯ
    categories = group_items_by_category(sales_stats)

    message = f"📊 Статистика за {month_name} {year} года\n\n"
    message += f"💰 Общая сумма продаж: {total_sales_amount}₽\n"
    message += f"🎫 Сумма списанных бонусов: {spent_bonuses}₽\n\n"
    message += "📈 Продажи по категориям:\n\n"

    # Выводим категории с группировкой
    for category_key in ['Кальяны', 'Чай', 'Коктейли', 'Напитки', 'Другое']:
        category_data = categories[category_key]
        if category_data['total_quantity'] > 0:
            message += f"{category_data['name']}:\n"
            message += f"  Всего: {category_data['total_quantity']} шт. - {category_data['total_amount']}₽\n"

            # Выводим детали по позициям внутри категории
            for item_name, item_data in category_data['items'].items():
                message += f"  • {item_name}: {item_data['quantity']} шт. - {item_data['total_amount']}₽\n"
            message += "\n"

    keyboard = [
        [InlineKeyboardButton("📅 Выбрать смену", callback_data=f"history_year_{year}")],
        [InlineKeyboardButton("📊 Другая статистика", callback_data="order_history")],
        [InlineKeyboardButton("⬅️ Назад в управление", callback_data="back_to_order_management")]
    ]

    try:
        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение статистики месяца не требует изменений")
        else:
            logger.error(f"Ошибка при показе статистики месяца: {e}")
            await message_manager.send_message(
                update, context,
                message,
                reply_markup=InlineKeyboardMarkup(keyboard),
                is_temporary=False
            )


async def show_selected_shift_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать историю выбранной смены - ОБНОВЛЕННАЯ ВЕРСИЯ С ГРУППИРОВКОЙ И БОНУСАМИ"""
    query = update.callback_query
    await query.answer()

    # Формат: history_shift_2024-11_30
    if "_" in query.data:
        parts = query.data.split("_")
        if len(parts) == 4:  # Формат: history_shift_2024-11_30
            month_year = parts[2]
            shift_number = int(parts[3])
        else:  # Старый формат: history_shift_30 (для обратной совместимости)
            shift_number = int(query.data.replace("history_shift_", ""))
            # Пытаемся найти смену по номеру
            shift = db.get_shift_by_number(shift_number)
            if not shift:
                await query.edit_message_text(f"📭 Нет данных по смене #{shift_number}.")
                return
            month_year = shift[2]
    else:
        await query.edit_message_text("❌ Неверный формат данных.")
        return

    # Получаем статистику по выбранной смене
    shift_sales = db.get_shift_sales(shift_number, month_year)
    shift_info = db.get_shift_by_number_and_month(shift_number, month_year)

    if not shift_sales or not shift_info:
        try:
            await query.edit_message_text(
                f"📭 Нет данных по смене #{shift_number} ({month_year}).",
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("⬅️ Назад", callback_data="history_select_shift")]])
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение отсутствия данных не требует изменений")
            else:
                logger.error(f"Ошибка при показе выбранной смены: {e}")
                await message_manager.send_message(
                    update, context,
                    f"📭 Нет данных по смене #{shift_number} ({month_year}).",
                    reply_markup=InlineKeyboardMarkup(
                        [[InlineKeyboardButton("⬅️ Назад", callback_data="history_select_shift")]]),
                    is_temporary=False
                )
        return

    total_revenue = shift_info[6] or 0
    total_orders = shift_info[7] or 0

    # Получаем сумму списанных бонусов за смену
    spent_bonuses = db.get_spent_bonuses_by_shift(shift_number, month_year)

    # Считаем общую сумму всех проданных позиций за смену
    total_sales_amount = sum(total_amount for _, _, total_amount in shift_sales)

    # Группируем позиции по категориям - ОБНОВЛЕННАЯ ФУНКЦИЯ
    categories = group_items_by_category(shift_sales)

    message = f"📊 Статистика за смену #{shift_number} ({month_year})\n\n"
    message += f"📅 Открыта: {format_datetime(shift_info[3])}\n"
    if shift_info[4]:
        message += f"📅 Закрыта: {format_datetime(shift_info[4])}\n"
    message += f"📋 Заказов: {total_orders}\n"
    message += f"💰 Сумма всех продаж: {total_sales_amount}₽\n"
    message += f"🎫 Сумма списанных бонусов: {spent_bonuses}₽\n\n"
    message += "📈 Продажи по категориям:\n\n"

    # Выводим категории с группировкой
    for category_key in ['Кальяны', 'Чай', 'Коктейли', 'Напитки', 'Другое']:
        category_data = categories[category_key]
        if category_data['total_quantity'] > 0:
            message += f"{category_data['name']}:\n"
            message += f"  Всего: {category_data['total_quantity']} шт. - {category_data['total_amount']}₽\n"

            # Выводим детали по позициям внутри категории
            for item_name, item_data in category_data['items'].items():
                message += f"  • {item_name}: {item_data['quantity']} шт. - {item_data['total_amount']}₽\n"
            message += "\n"

    keyboard = [
        [InlineKeyboardButton("📅 Выбрать другую смену", callback_data="history_select_shift")],
        [InlineKeyboardButton("⬅️ Назад в историю", callback_data="order_history")]
    ]

    try:
        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение выбранной смены не требует изменений")
        else:
            logger.error(f"Ошибка при показе выбранной смены: {e}")
            await message_manager.send_message(
                update, context,
                message,
                reply_markup=InlineKeyboardMarkup(keyboard),
                is_temporary=False
            )


async def show_select_shift_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать меню выбора смены - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    # Получаем список всех закрытых смен
    shifts = db.get_all_shifts_sorted()

    if not shifts:
        try:
            await query.edit_message_text(
                "📭 Нет закрытых смен для просмотра.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data="order_history")]])
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение отсутствия смен не требует изменений")
            else:
                logger.error(f"Ошибка при показе меню выбора смены: {e}")
                await message_manager.send_message(
                    update, context,
                    "📭 Нет закрытых смен для просмотра.",
                    reply_markup=InlineKeyboardMarkup(
                        [[InlineKeyboardButton("⬅️ Назад", callback_data="order_history")]]),
                    is_temporary=False
                )
        return

    keyboard = []
    for shift in shifts[:15]:  # Показываем последние 15 смен
        shift_number = shift[1]
        month_year = shift[2]
        opened_at = shift[3]

        # ИСПРАВЛЕНИЕ: Добавляем проверку типа
        if opened_at and isinstance(opened_at, str):
            opened_date = opened_at.split()[0] if ' ' in opened_at else opened_at
        else:
            opened_date = "Неизвестно"

        revenue = shift[6] or 0

        keyboard.append([InlineKeyboardButton(
            f"#{shift_number} ({month_year}) | {opened_date} | {revenue}₽",
            callback_data=f"history_shift_{month_year}_{shift_number}"  # Новый формат с месяцем
        )])

    keyboard.append([InlineKeyboardButton("⬅️ Назад", callback_data="order_history")])

    try:
        await query.edit_message_text(
            "📅 Выберите смену для просмотра:",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение выбора смены не требует изменений")
        else:
            logger.error(f"Ошибка при показе меню выбора смены: {e}")
            await message_manager.send_message(
                update, context,
                "📅 Выберите смену для просмотра:",
                reply_markup=InlineKeyboardMarkup(keyboard),
                is_temporary=False
            )


# Остальные функции истории заказов
async def show_today_orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать заказы за сегодня - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    today = datetime.now().strftime('%Y-%m-%d')
    orders = db.get_orders_by_date(today, status='closed')

    await show_orders_history(update, context, orders, f"за сегодня ({today})")


async def show_yesterday_orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать заказы за вчера"""
    query = update.callback_query
    await query.answer()

    yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
    orders = db.get_orders_by_date(yesterday, status='closed')

    await show_orders_history(update, context, orders, f"за вчера ({yesterday})")


async def show_all_closed_orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать все закрытые заказы - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    orders = db.get_all_closed_orders()

    await show_orders_history(update, context, orders, "все закрытые")


async def show_select_date_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать меню выбора даты - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    # Получаем список дат, по которым есть закрытые заказы
    dates = db.get_order_dates()

    if not dates:
        try:
            await query.edit_message_text(
                "📭 Нет доступных дат для просмотра.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data="order_history")]])
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение отсутствия дат не требует изменений")
            else:
                logger.error(f"Ошибка при показе меню дат: {e}")
                await message_manager.send_message(
                    update, context,
                    "📭 Нет доступных дат для просмотра.",
                    reply_markup=InlineKeyboardMarkup(
                        [[InlineKeyboardButton("⬅️ Назад", callback_data="order_history")]]),
                    is_temporary=False
                )
        return

    keyboard = []
    row = []
    for i, date in enumerate(dates):
        row.append(InlineKeyboardButton(date, callback_data=f"history_date_{date}"))
        if len(row) == 2 or i == len(dates) - 1:
            keyboard.append(row)
            row = []

    keyboard.append([InlineKeyboardButton("⬅️ Назад", callback_data="order_history")])

    try:
        await query.edit_message_text(
            "📅 Выберите дату для просмотра заказов:",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение меню дат не требует изменений")
        else:
            logger.error(f"Ошибка при показе меню дат: {e}")
            await message_manager.send_message(
                update, context,
                "📅 Выберите дату для просмотра заказов:",
                reply_markup=InlineKeyboardMarkup(keyboard),
                is_temporary=False
            )


async def show_orders_by_date(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать заказы по выбранной дате - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    date = query.data.replace("history_date_", "")
    orders = db.get_orders_by_date(date, status='closed')

    await show_orders_history(update, context, orders, f"за {date}")


async def show_orders_history(update: Update, context: ContextTypes.DEFAULT_TYPE, orders, period_text):
    """Показать историю заказов с полной информацией"""
    query = update.callback_query

    if not orders:
        await query.edit_message_text(
            f"📭 Нет закрытых заказов {period_text}.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data="order_history")]])
        )
        return

    total_revenue = 0
    total_orders = len(orders)

    message = f"📊 История заказов ({period_text})\n\n"
    message += f"📋 Всего заказов: {total_orders}\n"

    for order in orders:
        items = menu_manager.get_order_items(order[0])
        total = menu_manager.calculate_order_total(order[0])
        total_revenue += total

        # Получаем информацию об администраторе
        admin_info = "Неизвестный администратор"
        if order[2]:  # admin_id
            admin_data = db.get_user_by_id(order[2])
            if admin_data:
                admin_info = f"{admin_data[2]} {admin_data[3]} (ID: {admin_data[0]})"

        message += f"\n🧾 Заказ #{order[0]} | Стол {order[1]}\n"
        message += f"💰 Сумма: {total}₽\n"
        message += f"👨‍💼 Админ: {admin_info}\n"
        message += f"📅 Создан: {format_datetime(order[4])}\n"

        # Добавляем время закрытия если заказ закрыт
        if order[5]:  # closed_at
            message += f"📅 Закрыт: {format_datetime(order[5])}\n"

        # Показываем ВЕСЬ список товаров
        if items:
            message += "🛒 Позиции:\n"
            for item in items:
                item_total = item[3] * item[4]
                message += f"  • {item[2]} - {item[3]}₽ x {item[4]} = {item_total}₽\n"
        message += "─" * 30 + "\n"

    message += f"\n💰 Общая выручка: {total_revenue}₽"

    keyboard = [
        [InlineKeyboardButton("📊 Другая дата", callback_data="order_history")],
        [InlineKeyboardButton("⬅️ Назад в управление", callback_data="back_to_order_management")]
    ]

    # Если сообщение слишком длинное, разбиваем на части
    if len(message) > 4000:
        parts = []
        current_part = ""
        lines = message.split('\n')

        for line in lines:
            if len(current_part + line + '\n') < 4000:
                current_part += line + '\n'
            else:
                parts.append(current_part)
                current_part = line + '\n'

        if current_part:
            parts.append(current_part)

        # Отправляем первую часть с клавиатурой
        await query.edit_message_text(
            parts[0],
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

        # Остальные части отправляем как новые сообщения
        for part in parts[1:]:
            await message_manager.send_message(
                update, context,
                part,
                is_temporary=False
            )
    else:
        await query.edit_message_text(
            message,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )


async def handle_back_to_categories(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка кнопки возврата к категориям - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    try:
        await query.edit_message_text(
            "Выберите категорию меню:",
            reply_markup=menu_manager.get_category_keyboard()
        )
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение категорий не требует изменений")
        else:
            logger.error(f"Ошибка при возврате к категориям: {e}")
            await message_manager.send_message(
                update, context,
                "Выберите категорию меню:",
                reply_markup=menu_manager.get_category_keyboard(),
                is_temporary=False
            )


async def handle_back_to_order_management(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Возврат в управление заказами - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    try:
        await start_order_management(update, context)
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение не требует изменений при возврате в управление заказами")
        else:
            logger.error(f"Ошибка при возврате в управление заказами: {e}")
            await message_manager.send_message(
                update, context,
                "🍽️ Управление заказами",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("🔓 Открыть смену", callback_data="open_shift"),
                    InlineKeyboardButton("📊 История заказов", callback_data="order_history")
                ], [
                    InlineKeyboardButton("⬅️ Назад", callback_data="back_to_admin")
                ]]),
                is_temporary=False
            )


async def handle_order_buttons_outside_conversation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка кнопок заказов вне ConversationHandler - ОБНОВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    # ПРИНУДИТЕЛЬНАЯ ОТЛАДКА - ДОБАВЬТЕ ЭТО
    print(f"🎯 DEBUG: Получен callback_data: '{query.data}'")
    print(f"🎯 DEBUG: User: {query.from_user.id}, Message: {query.message.message_id}")

    if query.data.startswith("add_items_"):
        return await handle_add_items(update, context)
    elif query.data.startswith("view_order_"):
        return await view_order_details(update, context)
    elif query.data.startswith("calculate_"):
        return await calculate_order(update, context)
    elif query.data.startswith("edit_order_"):  # НОВЫЙ ОБРАБОТЧИК
        return await show_order_for_editing(update, context)
    elif query.data.startswith("remove_item_"):  # НОВЫЙ ОБРАБОТЧИК
        return await remove_item_from_order(update, context)
    elif query.data == "active_orders":
        return await show_active_orders(update, context)
    elif query.data == "back_to_admin":
        return await back_to_admin_main(update, context)
    elif query.data == "cancel_calculation":
        return await handle_cancel_calculation(update, context)
    elif query.data == "order_history":
        return await show_order_history_menu(update, context)
    elif query.data == "history_today":
        return await show_today_orders(update, context)
    elif query.data == "history_shift":
        return await show_shift_history(update, context)
    elif query.data == "history_month":
        return await show_month_history(update, context)
    elif query.data == "history_year":
        return await show_year_history(update, context)
    elif query.data == "history_select_shift":
        return await show_select_shift_menu(update, context)
    elif query.data.startswith("history_shift_"):  # Обработка нового формата
        return await show_selected_shift_history(update, context)
    elif query.data == "history_all":
        return await show_all_closed_orders(update, context)
    elif query.data == "history_select_date":
        return await show_select_date_menu(update, context)
    elif query.data.startswith("history_date_"):
        return await show_orders_by_date(update, context)
    elif query.data == "back_to_order_management":
        return await handle_back_to_order_management(update, context)
    # Добавляем обработчики управления сменой
    elif query.data == "open_shift":
        return await open_shift(update, context)
    elif query.data == "close_shift":
        return await close_shift(update, context)
    elif query.data == "calculate_all_orders":
        return await calculate_all_orders(update, context)
    elif query.data == "shift_status":
        return await show_shift_status(update, context)
    # Добавляем обработчики новой статистики
    elif query.data.startswith("history_full_year_"):
        return await show_full_year_history(update, context)
    elif query.data.startswith("history_full_month_"):
        return await show_full_month_history(update, context)
    elif query.data.startswith("history_month_more_"):  # НОВЫЙ ОБРАБОТЧИК ПАГИНАЦИИ
        return await show_more_shifts(update, context)
    elif query.data.startswith("history_month_"):  # Обработка выбора месяца
        return await select_month_for_history(update, context)
    elif query.data.startswith("history_year_"):  # Обработка выбора года
        return await select_year_for_history(update, context)
    else:
        await query.edit_message_text("❌ Неизвестная команда")