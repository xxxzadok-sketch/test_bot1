from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, MessageHandler, filters, CommandHandler, CallbackQueryHandler, \
    ConversationHandler
from config import ADMIN_IDS
from database import Database
from keyboards.menus import get_admin_main_menu, get_users_keyboard, get_user_actions_keyboard, get_cancel_keyboard, \
    get_booking_actions_keyboard, get_bonus_request_keyboard, get_booking_filter_menu
from message_manager import message_manager
from handlers.menu_management_handlers import manage_menu  # ДОБАВЛЕН НОВЫЙ ИМПОРТ
import logging
import asyncio
from datetime import datetime

logger = logging.getLogger(__name__)

db = Database()

# Состояния для админских функций
AWAITING_BROADCAST, AWAITING_USER_MESSAGE, SELECTING_USER, AWAITING_BONUS_AMOUNT, AWAITING_SPENT_AMOUNT, AWAITING_BROADCAST_MEDIA, SELECTING_YEAR, SELECTING_MONTH, SELECTING_DATE, AWAITING_CANCELLATION_REASON, AWAITING_SEARCH_QUERY = range(
    11)


def is_admin(user_id):
    return user_id in ADMIN_IDS


async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await message_manager.send_message(update, context, "❌ У вас нет доступа к этой команде.", is_temporary=True)
        return

    # ПОЛНАЯ ОЧИСТКА всех сообщений при входе в админ-панель
    await message_manager.cleanup_all_messages(context, update.effective_user.id)

    # ГЛАВНОЕ МЕНЮ - ПОСТОЯННОЕ сообщение
    await message_manager.send_message(
        update, context,
        "👨‍💼 Панель администратора",
        reply_markup=get_admin_main_menu(),
        is_temporary=False
    )


async def show_users_list(update: Update, context: ContextTypes.DEFAULT_TYPE, page=0):
    if not is_admin(update.effective_user.id):
        return

    # Очищаем только временные сообщения при переходе между разделами
    await message_manager.cleanup_user_messages(context, update.effective_user.id)

    # АВТОМАТИЧЕСКИ ЗАПУСКАЕМ РЕЖИМ ПОИСКА!
    # Показываем сообщение о поиске
    await message_manager.send_message(
        update, context,
        "🔍 Режим поиска пользователей активен!\n\n"
        "📌 Просто напишите в чат:\n"
        "• ID пользователя (например: 123)\n"
        "• Имя или фамилию (например: Иван)\n"
        "• Часть имени\n\n"
        "Или нажмите кнопку для просмотра полного списка:",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("📋 Показать полный список", callback_data="show_full_users_list_0")],
            [InlineKeyboardButton("❌ Выйти из поиска", callback_data="exit_search_mode")]
        ]),
        is_temporary=False
    )

    # Устанавливаем флаг режима поиска
    context.user_data['search_users_mode'] = True

    return  # Не показываем список сразу


async def start_user_search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Начать поиск пользователя"""
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        return

    await query.edit_message_text(
        "🔍 Поиск пользователя\n\n"
        "Введите ID пользователя, имя или фамилию для поиска:",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("❌ Отмена", callback_data="cancel_search")]
        ])
    )
    return AWAITING_SEARCH_QUERY


async def process_user_search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка поиска пользователя"""
    if not is_admin(update.effective_user.id):
        return

    search_query = update.message.text.strip()

    if not search_query:
        await message_manager.send_message(
            update, context,
            "❌ Введите текст для поиска.",
            is_temporary=True
        )
        return AWAITING_SEARCH_QUERY

    # Ищем пользователей в базе данных
    cursor = db.conn.cursor()

    # Поиск по ID
    if search_query.isdigit():
        cursor.execute('''
            SELECT * FROM users 
            WHERE id = ? AND is_active = TRUE 
            ORDER BY id DESC
        ''', (int(search_query),))
    else:
        # Поиск по имени или фамилии
        search_pattern = f"%{search_query}%"
        cursor.execute('''
            SELECT * FROM users 
            WHERE (first_name LIKE ? OR last_name LIKE ?) AND is_active = TRUE 
            ORDER BY id DESC
        ''', (search_pattern, search_pattern))

    users = cursor.fetchall()

    if not users:
        await message_manager.send_message(
            update, context,
            f"❌ Пользователи по запросу '{search_query}' не найдены.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ Назад к списку", callback_data="back_to_users_list")]
            ]),
            is_temporary=False
        )
        return ConversationHandler.END

    # Показываем найденных пользователей
    message = f"🔍 Результаты поиска по запросу: '{search_query}'\n\n"
    message += f"Найдено пользователей: {len(users)}\n\n"

    keyboard = []

    for user in users:
        keyboard.append([InlineKeyboardButton(
            f"{user[2]} {user[3]} (ID: {user[0]}) | 💰 {user[5]} баллов",
            callback_data=f"select_user_{user[0]}"
        )])

    keyboard.append([InlineKeyboardButton("⬅️ Назад к списку", callback_data="back_to_users_list")])

    await message_manager.send_message(
        update, context,
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        is_temporary=False
    )

    return ConversationHandler.END


async def cancel_search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отмена поиска"""
    query = update.callback_query
    await query.answer()

    await show_users_list(update, context, 0)
    return ConversationHandler.END


async def back_to_users_list(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Возврат к списку пользователей"""
    query = update.callback_query
    await query.answer()

    try:
        # Исправлено: редактируем текущее сообщение вместо отправки нового
        await query.edit_message_text(
            "🔄 Загружаю список пользователей...",
            reply_markup=None
        )

        # Небольшая задержка для UX
        await asyncio.sleep(0.5)

        # Вызываем функцию показа списка пользователей
        # Для этого создаем "обертку" для callback query
        from handlers.admin_handlers import show_users_list

        # Используем message_manager для отправки нового сообщения
        await message_manager.send_message(
            update, context,
            "👥 Список пользователей",
            reply_markup=None,
            is_temporary=False
        )

        # Вызываем show_users_list с page=0
        await show_users_list(update, context, 0)

    except Exception as e:
        logger.error(f"Ошибка при возврате к списку пользователей: {e}")
        # В случае ошибки просто показываем список
        await show_users_list(update, context, 0)

    return ConversationHandler.END


async def handle_users_pagination(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка пагинации списка пользователей"""
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        return

    if query.data.startswith("users_page_"):
        page = int(query.data.split("_")[2])
        await show_users_list(update, context, page)
    elif query.data == "refresh_users":
        await show_users_list(update, context, 0)


async def user_selected_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора пользователя - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        return

    user_id = int(query.data.split('_')[-1])
    user_data = db.get_user_by_id(user_id)

    if user_data:
        # Получаем информацию о рефералах
        referral_stats = db.get_referrer_stats(user_id)
        total_referrals = referral_stats[0] if referral_stats else 0

        message = (
            f"👤 Пользователь:\n\n"
            f"🆔 ID: {user_data[0]}\n"
            f"👤 Имя: {user_data[2]} {user_data[3]}\n"
            f"📱 Телефон: {user_data[4]}\n"
            f"💰 Баланс: {user_data[5]} баллов\n"
            f"📅 Дата регистрации: {user_data[6]}\n"
            f"👥 Приглашено друзей: {total_referrals}\n"
            f"🔗 Telegram ID: {user_data[1]}"
        )

        try:
            await query.edit_message_text(
                message,
                reply_markup=get_user_actions_keyboard(user_id)
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение пользователя не требует изменений")
            else:
                logger.error(f"Ошибка при показе пользователя: {e}")
                await message_manager.send_message(
                    update, context,
                    message,
                    reply_markup=get_user_actions_keyboard(user_id),
                    is_temporary=False
                )
    else:
        try:
            await query.edit_message_text("❌ Пользователь не найден.")
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение ошибки пользователя не требует изменений")
            else:
                logger.error(f"Ошибка при показе пользователя: {e}")
                await message_manager.send_message(
                    update, context,
                    "❌ Пользователь не найден.",
                    is_temporary=True
                )


async def user_info_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка кнопки информации о пользователе - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        return

    user_id = int(query.data.split('_')[-1])
    user_data = db.get_user_by_id(user_id)

    if user_data:
        message = (
            f"👤 Информация о пользователе:\n\n"
            f"🆔 ID: {user_data[0]}\n"
            f"👤 Имя: {user_data[2]}\n"
            f"📝 Фамилия: {user_data[3]}\n"
            f"📱 Телефон: {user_data[4]}\n"
            f"💰 Баланс: {user_data[5]} баллов\n"
            f"📅 Регистрация: {user_data[6]}\n"
            f"🔗 Telegram ID: {user_data[1]}"
        )

        try:
            await query.edit_message_text(
                message,
                reply_markup=get_user_actions_keyboard(user_id)
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение информации о пользователе не требует изменений")
            else:
                logger.error(f"Ошибка при показе информации о пользователе: {e}")
                await message_manager.send_message(
                    update, context,
                    message,
                    reply_markup=get_user_actions_keyboard(user_id),
                    is_temporary=False
                )
    else:
        try:
            await query.edit_message_text("❌ Пользователь не найден.")
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение ошибки пользователя не требует изменений")
            else:
                logger.error(f"Ошибка при показе информации о пользователе: {e}")
                await message_manager.send_message(
                    update, context,
                    "❌ Пользователь не найден.",
                    is_temporary=True
                )


# СИСТЕМА ФИЛЬТРАЦИИ БРОНИРОВАНИЙ
async def show_bookings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return

    # Очищаем только временные сообщения при переходе между разделами
    await message_manager.cleanup_user_messages(context, update.effective_user.id)

    # Получаем статистику бронирований
    stats = db.get_booking_stats()

    message = (
        "📅 Управление бронированиями\n\n"
        f"📊 Статистика:\n"
        f"⏳ Ожидающие: {stats.get('pending', 0)}\n"
        f"✅ Подтвержденные: {stats.get('confirmed', 0)}\n"
        f"❌ Отмененные: {stats.get('cancelled', 0)}\n"
        f"📋 Всего: {stats.get('total', 0)}\n\n"
        "Выберите тип фильтрации:"
    )

    # МЕНЮ ФИЛЬТРАЦИИ - ПОСТОЯННОЕ сообщение
    await message_manager.send_message(
        update, context,
        message,
        reply_markup=get_booking_filter_menu(),
        is_temporary=False
    )


async def show_pending_bookings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать ожидающие бронирования - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    if not is_admin(update.effective_user.id):
        return

    # Очищаем только временные сообщения при переходе между разделами
    await message_manager.cleanup_user_messages(context, update.effective_user.id)

    bookings = db.get_bookings_by_status('pending')

    # ОТЛАДОЧНАЯ ИНФОРМАЦИЯ
    logger.info(f"🔍 Админ запросил ожидающие бронирования: {len(bookings)}")
    for i, booking in enumerate(bookings):
        logger.info(f"📋 Бронирование {i + 1}: ID={booking[0]}, Статус={booking[5]}")

    if not bookings:
        try:
            await message_manager.send_message(
                update, context,
                "⏳ Нет ожидающих бронирований.",
                reply_markup=get_booking_filter_menu(),
                is_temporary=True
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение отсутствия бронирований не требует изменений")
            else:
                logger.error(f"Ошибка при показе ожидающих бронирований: {e}")
        return

    try:
        await message_manager.send_message(
            update, context,
            f"⏳ Ожидающие бронирования ({len(bookings)}):",
            reply_markup=get_booking_filter_menu(),
            is_temporary=False
        )
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение ожидающих бронирований не требует изменений")
        else:
            logger.error(f"Ошибка при показе ожидающих бронирований: {e}")

    for booking in bookings:
        message = _format_booking_message(booking)
        logger.info(f"📤 Отправка бронирования ID={booking[0]} с кнопками действий")

        try:
            await message_manager.send_message(
                update, context,
                message,
                reply_markup=get_booking_actions_keyboard(booking[0]),
                is_temporary=False
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение бронирования не требует изменений")
            else:
                logger.error(f"Ошибка при отправке бронирования: {e}")


async def show_confirmed_bookings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать подтвержденные бронирования - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    if not is_admin(update.effective_user.id):
        return

    # Очищаем только временные сообщения при переходе между разделами
    await message_manager.cleanup_user_messages(context, update.effective_user.id)

    bookings = db.get_bookings_by_status('confirmed')

    if not bookings:
        try:
            await message_manager.send_message(
                update, context,
                "✅ Нет подтвержденных бронирований.",
                reply_markup=get_booking_filter_menu(),
                is_temporary=True
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение отсутствия подтвержденных бронирований не требует изменений")
            else:
                logger.error(f"Ошибка при показе подтвержденных бронирований: {e}")
        return

    try:
        await message_manager.send_message(
            update, context,
            f"✅ Подтвержденные бронирования ({len(bookings)}):",
            reply_markup=get_booking_filter_menu(),
            is_temporary=False
        )
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение подтвержденных бронирований не требует изменений")
        else:
            logger.error(f"Ошибка при показе подтвержденных бронирований: {e}")

    for booking in bookings:
        message = _format_booking_message(booking)

        try:
            await message_manager.send_message(
                update, context,
                message,
                is_temporary=False
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение подтвержденного бронирования не требует изменений")
            else:
                logger.error(f"Ошибка при отправке подтвержденного бронирования: {e}")


async def show_cancelled_bookings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать отмененные бронирования - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    if not is_admin(update.effective_user.id):
        return

    # Очищаем только временные сообщения при переходе между разделами
    await message_manager.cleanup_user_messages(context, update.effective_user.id)

    bookings = db.get_bookings_by_status('cancelled')

    if not bookings:
        try:
            await message_manager.send_message(update, context, "❌ Нет отмененных бронирований.", is_temporary=True)
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение отсутствия отмененных бронирований не требует изменений")
            else:
                logger.error(f"Ошибка при показе отмененных бронирований: {e}")
        return

    try:
        await message_manager.send_message(update, context, f"❌ Отмененные бронирования ({len(bookings)}):",
                                           is_temporary=False)
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение отмененных бронирований не требует изменений")
        else:
            logger.error(f"Ошибка при показе отмененных бронирований: {e}")

    for booking in bookings:
        message = _format_booking_message(booking)

        try:
            await message_manager.send_message(
                update, context,
                message,
                is_temporary=False
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение отмененного бронирования не требует изменений")
            else:
                logger.error(f"Ошибка при отправке отмененного бронирования: {e}")


async def show_all_bookings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать все бронирования - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    if not is_admin(update.effective_user.id):
        return

    # Очищаем только временные сообщения при переходе между разделами
    await message_manager.cleanup_user_messages(context, update.effective_user.id)

    bookings = db.get_all_bookings_sorted()

    if not bookings:
        try:
            await message_manager.send_message(update, context, "📭 Бронирования не найдены.", is_temporary=True)
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение отсутствия бронирований не требует изменений")
            else:
                logger.error(f"Ошибка при показе всех бронирований: {e}")
        return

    try:
        await message_manager.send_message(update, context, f"📋 Все бронирования ({len(bookings)}):",
                                           is_temporary=False)
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение всех бронирований не требует изменений")
        else:
            logger.error(f"Ошибка при показе всех бронирований: {e}")

    for booking in bookings:
        message = _format_booking_message(booking)

        # Для ожидающих бронирований показываем кнопки действий
        if booking[5] == 'pending':
            try:
                await message_manager.send_message(
                    update, context,
                    message,
                    reply_markup=get_booking_actions_keyboard(booking[0]),
                    is_temporary=False
                )
            except Exception as e:
                if "Message is not modified" in str(e):
                    logger.debug("Сообщение бронирования с кнопками не требует изменений")
                else:
                    logger.error(f"Ошибка при отправке бронирования с кнопками: {e}")
        else:
            try:
                await message_manager.send_message(
                    update, context,
                    message,
                    is_temporary=False
                )
            except Exception as e:
                if "Message is not modified" in str(e):
                    logger.debug("Сообщение бронирования не требует изменений")
                else:
                    logger.error(f"Ошибка при отправке бронирования: {e}")


def debug_booking_dates():
    """Отладочная функция для проверки данных бронирований"""
    cursor = db.conn.cursor()
    try:
        # Проверяем структуру таблицы
        cursor.execute("PRAGMA table_info(bookings)")
        columns = cursor.fetchall()
        logger.info("🔍 Структура таблицы bookings:")
        for col in columns:
            logger.info(f"   {col}")

        # Проверяем данные
        cursor.execute('''
            SELECT id, booking_date, status 
            FROM bookings 
            ORDER BY booking_date DESC 
            LIMIT 10
        ''')
        recent_bookings = cursor.fetchall()
        logger.info("🔍 Последние 10 бронирований:")
        for booking in recent_bookings:
            logger.info(f"   ID: {booking[0]}, Дата: {booking[1]}, Статус: {booking[2]}")

        # Проверяем уникальные даты
        cursor.execute('''
            SELECT DISTINCT booking_date 
            FROM bookings 
            WHERE booking_date IS NOT NULL 
            ORDER BY booking_date DESC
        ''')
        unique_dates = cursor.fetchall()
        logger.info("🔍 Уникальные даты бронирований:")
        for date in unique_dates:
            logger.info(f"   Дата: {date[0]}")

        return True
    except Exception as e:
        logger.error(f"❌ Ошибка при отладке бронирований: {e}")
        return False


def create_test_bookings():
    """Создать тестовые бронирования для проверки фильтрации"""
    cursor = db.conn.cursor()
    try:
        # Получаем первого пользователя
        cursor.execute("SELECT id FROM users LIMIT 1")
        user = cursor.fetchone()

        if not user:
            logger.info("❌ Нет пользователей для создания тестовых бронирований")
            return False

        user_id = user[0]

        # Создаем тестовые бронирования на разные даты
        test_dates = [
            '2024-11-15', '2024-11-16', '2024-12-01',
            '2025-01-10', '2025-02-15', '2025-03-20'
        ]

        for date in test_dates:
            cursor.execute('''
                INSERT INTO bookings (user_id, booking_date, booking_time, guests, created_at, status)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (user_id, date, '19:00', 2, db.get_moscow_time(), 'confirmed'))

        db.conn.commit()
        logger.info(f"✅ Создано {len(test_dates)} тестовых бронирований")
        return True

    except Exception as e:
        logger.error(f"❌ Ошибка при создании тестовых бронирований: {e}")
        return False


# Функции для фильтрации бронирований по году/месяцу/дате
def get_booking_years():
    """Получить список годов, в которых есть бронирования"""
    cursor = db.conn.cursor()
    try:
        # Получаем все даты и извлекаем год вручную
        cursor.execute('''
            SELECT DISTINCT booking_date 
            FROM bookings 
            WHERE booking_date IS NOT NULL AND booking_date != ''
            ORDER BY booking_date DESC
        ''')
        dates = cursor.fetchall()

        years_set = set()
        for date_tuple in dates:
            date_str = date_tuple[0]
            if date_str and '.' in date_str:
                try:
                    # Извлекаем год из формата DD.MM.YYYY
                    day, month, year = date_str.split('.')
                    if len(year) == 4 and year.isdigit():
                        years_set.add(year)
                except ValueError:
                    continue

        # Сортируем годы по убыванию
        years = sorted(years_set, reverse=True)
        logger.info(f"🔍 Найдено годов с бронированиями: {years}")
        return years

    except Exception as e:
        logger.error(f"❌ Ошибка при получении годов бронирований: {e}")
        return []


def get_booking_months(year):
    """Получить список месяцев для указанного года"""
    cursor = db.conn.cursor()
    try:
        # Получаем все даты и фильтруем по году вручную
        cursor.execute('''
            SELECT DISTINCT booking_date 
            FROM bookings 
            WHERE booking_date IS NOT NULL AND booking_date != ''
            ORDER BY booking_date DESC
        ''')
        dates = cursor.fetchall()

        months_set = set()
        for date_tuple in dates:
            date_str = date_tuple[0]
            if date_str and '.' in date_str:
                try:
                    # Извлекаем год и месяц из формата DD.MM.YYYY
                    day, month, date_year = date_str.split('.')
                    if date_year == year and len(month) == 2 and month.isdigit():
                        months_set.add(month)
                except ValueError:
                    continue

        # Сортируем месяцы по убыванию
        months = sorted(months_set, reverse=True)
        logger.info(f"🔍 Найдено месяцев за {year} год: {months}")
        return months

    except Exception as e:
        logger.error(f"❌ Ошибка при получении месяцев бронирований: {e}")
        return []


def get_booking_dates_by_year_month(year, month):
    """Получить список дат для указанного года и месяца"""
    cursor = db.conn.cursor()
    try:
        # Получаем все даты и фильтруем по году и месяцу вручную
        cursor.execute('''
            SELECT DISTINCT booking_date 
            FROM bookings 
            WHERE booking_date IS NOT NULL AND booking_date != ''
            ORDER BY booking_date DESC
        ''')
        dates = cursor.fetchall()

        filtered_dates = []
        for date_tuple in dates:
            date_str = date_tuple[0]
            if date_str and '.' in date_str:
                try:
                    # Извлекаем компоненты даты из формата DD.MM.YYYY
                    day, date_month, date_year = date_str.split('.')
                    if date_year == year and date_month == month:
                        filtered_dates.append(date_str)
                except ValueError:
                    continue

        logger.info(f"🔍 Найдено дат за {month}.{year}: {filtered_dates}")
        return filtered_dates

    except Exception as e:
        logger.error(f"❌ Ошибка при получении дат бронирований: {e}")
        return []


async def show_dates_for_filter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать список годов для фильтрации"""
    if not is_admin(update.effective_user.id):
        return

    years = get_booking_years()

    if not years:
        await message_manager.send_message(
            update, context,
            "📭 Нет доступных годов для фильтрации.",
            reply_markup=get_booking_filter_menu(),
            is_temporary=True
        )
        return

    keyboard = []
    for year in years:
        keyboard.append([KeyboardButton(f"📅 {year} год")])
    keyboard.append([KeyboardButton("❌ Отмена")])

    # ОТКЛЮЧАЕМ очистку сообщений - убираем cleanup_user_messages
    await message_manager.send_message(
        update, context,
        "📅 Выберите год для просмотра бронирований:",
        reply_markup=ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True),
        is_temporary=False
    )
    return SELECTING_YEAR


async def select_year_for_filter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора года"""
    if update.message.text == "❌ Отмена":
        await message_manager.send_message(
            update, context,
            "❌ Поиск по дате отменен.",
            reply_markup=get_booking_filter_menu(),
            is_temporary=True
        )
        return ConversationHandler.END

    if not is_admin(update.effective_user.id):
        return

    year = update.message.text.replace("📅 ", "").replace(" год", "").strip()
    context.user_data['selected_year'] = year

    months = get_booking_months(year)

    if not months:
        await message_manager.send_message(
            update, context,
            f"📭 Нет бронирований за {year} год.",
            reply_markup=get_booking_filter_menu(),
            is_temporary=True
        )
        return ConversationHandler.END

    keyboard = []
    month_names = {
        '01': 'Январь', '02': 'Февраль', '03': 'Март', '04': 'Апрель',
        '05': 'Май', '06': 'Июнь', '07': 'Июль', '08': 'Август',
        '09': 'Сентябрь', '10': 'Октябрь', '11': 'Ноябрь', '12': 'Декабрь'
    }

    for month in months:
        month_name = month_names.get(month, month)
        keyboard.append([KeyboardButton(f"📆 {month_name}")])
    keyboard.append([KeyboardButton("❌ Отмена")])

    # БЕЗ очистки сообщений
    await message_manager.send_message(
        update, context,
        f"📅 Выберите месяц {year} года:",
        reply_markup=ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True),
        is_temporary=False
    )
    return SELECTING_MONTH


async def select_month_for_filter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора месяца"""
    if update.message.text == "❌ Отмена":
        await message_manager.send_message(
            update, context,
            "❌ Поиск по дате отменен.",
            reply_markup=get_booking_filter_menu(),
            is_temporary=True
        )
        return ConversationHandler.END

    if not is_admin(update.effective_user.id):
        return

    month_text = update.message.text.replace("📆 ", "").strip()
    month_names = {
        'Январь': '01', 'Февраль': '02', 'Март': '03', 'Апрель': '04',
        'Май': '05', 'Июнь': '06', 'Июль': '07', 'Август': '08',
        'Сентябрь': '09', 'Октябрь': '10', 'Ноябрь': '11', 'Декабрь': '12'
    }

    month = month_names.get(month_text)
    if not month:
        await message_manager.send_message(
            update, context,
            "❌ Неверный месяц.",
            is_temporary=True
        )
        return SELECTING_MONTH

    year = context.user_data['selected_year']
    context.user_data['selected_month'] = month

    dates = get_booking_dates_by_year_month(year, month)

    if not dates:
        await message_manager.send_message(
            update, context,
            f"📭 Нет бронирований за {month_text} {year} года.",
            reply_markup=get_booking_filter_menu(),
            is_temporary=True
        )
        return ConversationHandler.END

    keyboard = []
    for date in dates:
        # Даты уже в формате DD.MM.YYYY, просто используем как есть
        keyboard.append([KeyboardButton(date)])
    keyboard.append([KeyboardButton("❌ Отмена")])

    await message_manager.send_message(
        update, context,
        f"📅 Выберите дату ({month_text} {year}):",
        reply_markup=ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True),
        is_temporary=False
    )
    return SELECTING_DATE


async def show_bookings_by_selected_date(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать бронирования по выбранной дате"""
    if update.message.text == "❌ Отмена":
        await message_manager.send_message(
            update, context,
            "❌ Поиск по дате отменен.",
            reply_markup=get_booking_filter_menu(),
            is_temporary=True
        )
        return ConversationHandler.END

    if not is_admin(update.effective_user.id):
        return

    selected_date = update.message.text.strip()
    # Дата уже в формате DD.MM.YYYY, используем как есть
    formatted_date = selected_date

    bookings = db.get_bookings_by_date(formatted_date)

    if not bookings:
        await message_manager.send_message(
            update, context,
            f"📭 На {selected_date} бронирований не найдено.",
            reply_markup=get_booking_filter_menu(),
            is_temporary=True
        )
        return ConversationHandler.END

    await message_manager.send_message(
        update, context,
        f"📅 Бронирования на {selected_date} ({len(bookings)}):",
        reply_markup=get_booking_filter_menu(),
        is_temporary=False
    )

    for booking in bookings:
        message = _format_booking_message(booking)

        # Для ожидающих бронирований показываем кнопки действий
        if booking[5] == 'pending':
            await message_manager.send_message(
                update, context,
                message,
                reply_markup=get_booking_actions_keyboard(booking[0]),
                is_temporary=False
            )
        else:
            await message_manager.send_message(
                update, context,
                message,
                is_temporary=False
            )

    return ConversationHandler.END


def _format_booking_message(booking):
    """Форматирует сообщение о бронировании"""
    status_emoji = {
        'pending': '⏳',
        'confirmed': '✅',
        'cancelled': '❌'
    }

    status_text = {
        'pending': 'Ожидание',
        'confirmed': 'Подтверждено',
        'cancelled': 'Отменено'
    }

    return (
        f"{status_emoji.get(booking[5], '📅')} Бронирование #{booking[0]}\n"
        f"👤 {booking[7]} {booking[8]}\n"
        f"📱 {booking[9]}\n"
        f"📅 Дата: {booking[2]}\n"
        f"⏰ Время: {booking[3]}\n"
        f"👥 Гостей: {booking[4]}\n"
        f"📊 Статус: {status_text.get(booking[5], booking[5])}\n"
        f"🆔 ID брони: {booking[0]}"
    )


# ОБРАБОТКА ДЕЙСТВИЙ С БРОНИРОВАНИЯМИ
async def handle_booking_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка действий с бронированиями - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        return

    # Исправленный разбор callback данных
    parts = query.data.split('_')
    if len(parts) < 3:
        try:
            await query.edit_message_text("❌ Ошибка в данных запроса.")
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение ошибки данных не требует изменений")
            else:
                logger.error(f"Ошибка при обработке бронирования: {e}")
                await message_manager.send_message(
                    update, context,
                    "❌ Ошибка в данных запроса.",
                    is_temporary=True
                )
        return

    action = parts[0] + '_' + parts[1]  # "confirm_booking" или "cancel_booking"
    booking_id = parts[2]  # ID бронирования

    try:
        booking_id = int(booking_id)
    except ValueError:
        try:
            await query.edit_message_text("❌ Неверный ID бронирования.")
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение ошибки ID не требует изменений")
            else:
                logger.error(f"Ошибка при обработке бронирования: {e}")
                await message_manager.send_message(
                    update, context,
                    "❌ Неверный ID бронирования.",
                    is_temporary=True
                )
        return

    # Находим бронирование
    cursor = db.conn.cursor()
    cursor.execute('''
        SELECT b.*, u.first_name, u.last_name, u.telegram_id
        FROM bookings b 
        JOIN users u ON b.user_id = u.id 
        WHERE b.id = ?
    ''', (booking_id,))
    booking = cursor.fetchone()

    if not booking:
        try:
            await query.edit_message_text("❌ Бронирование не найдено.")
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение ошибки бронирования не требует изменений")
            else:
                logger.error(f"Ошибка при обработке бронирования: {e}")
                await message_manager.send_message(
                    update, context,
                    "❌ Бронирование не найдено.",
                    is_temporary=True
                )
        return

    # Исправленные индексы
    booking_id = booking[0]
    booking_date = booking[2]
    booking_time = booking[3]
    guests = booking[4]
    user_first_name = booking[7]
    user_last_name = booking[8]
    user_telegram_id = booking[9]

    if action == 'confirm_booking':
        # Подтверждаем бронирование
        cursor.execute('UPDATE bookings SET status = ? WHERE id = ?', ('confirmed', booking_id))
        db.conn.commit()

        # Уведомляем пользователя
        try:
            await context.bot.send_message(
                user_telegram_id,
                f"✅ Ваше бронирование подтверждено!\n\n"
                f"📅 Дата: {booking_date}\n"
                f"⏰ Время: {booking_time}\n"
                f"👥 Гостей: {guests}\n\n"
                f"Ждем вас в нашем заведении!"
            )
        except Exception as e:
            logger.error(f"Не удалось уведомить пользователя: {e}")

        try:
            await query.edit_message_text(
                f"✅ Бронирование #{booking_id} подтверждено.\n"
                f"👤 Пользователь: {user_first_name} {user_last_name}"
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение подтверждения бронирования не требует изменений")
            else:
                logger.error(f"Ошибка при подтверждении бронирования: {e}")
                await message_manager.send_message(
                    update, context,
                    f"✅ Бронирование #{booking_id} подтверждено.\n👤 Пользователь: {user_first_name} {user_last_name}",
                    is_temporary=False
                )

    elif action == 'cancel_booking':
        # Отменяем бронирование
        cursor.execute('UPDATE bookings SET status = ? WHERE id = ?', ('cancelled', booking_id))
        db.conn.commit()

        # Уведомляем пользователя
        try:
            await context.bot.send_message(
                user_telegram_id,
                f"❌ Ваше бронирование отменено.\n\n"
                f"📅 Дата: {booking_date}\n"
                f"⏰ Время: {booking_time}\n"
                f"👥 Гостей: {guests}\n\n"
                f"Если у вас есть вопросы, свяжитесь с нами."
            )
        except Exception as e:
            logger.error(f"Не удалось уведомить пользователя: {e}")

        try:
            await query.edit_message_text(
                f"❌ Бронирование #{booking_id} отменено.\n"
                f"👤 Пользователь: {user_first_name} {user_last_name}"
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение отмены бронирования не требует изменений")
            else:
                logger.error(f"Ошибка при отмене бронирования: {e}")
                await message_manager.send_message(
                    update, context,
                    f"❌ Бронирование #{booking_id} отменено.\n👤 Пользователь: {user_first_name} {user_last_name}",
                    is_temporary=False
                )
    else:
        try:
            await query.edit_message_text("❌ Неизвестное действие.")
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение неизвестного действия не требует изменений")
            else:
                logger.error(f"Ошибка при обработке бронирования: {e}")
                await message_manager.send_message(
                    update, context,
                    "❌ Неизвестное действие.",
                    is_temporary=True
                )


async def handle_booking_cancellation_with_reason(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка отмены бронирования с запросом причины - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        return

    # Получаем ID бронирования
    booking_id = int(query.data.split('_')[-1])
    context.user_data['cancelling_booking_id'] = booking_id

    # Запрашиваем причину отмены
    try:
        await query.edit_message_text(
            "📝 Укажите причину отмены бронирования:",
            reply_markup=get_cancel_keyboard()
        )
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение запроса причины не требует изменений")
        else:
            logger.error(f"Ошибка при запросе причины отмены: {e}")
            await message_manager.send_message(
                update, context,
                "📝 Укажите причину отмены бронирования:",
                reply_markup=get_cancel_keyboard(),
                is_temporary=False
            )
    return AWAITING_CANCELLATION_REASON


async def process_cancellation_reason(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка причины отмены бронирования - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    if update.message.text == "❌ Отмена":
        context.user_data.pop('cancelling_booking_id', None)
        await message_manager.send_message(
            update, context,
            "❌ Отмена бронирования отменена.",
            is_temporary=True
        )
        # ДОБАВЛЕНО: Возврат в главное меню
        await back_to_main_menu(update, context)
        return ConversationHandler.END

    if not is_admin(update.effective_user.id) or 'cancelling_booking_id' not in context.user_data:
        return

    reason = update.message.text
    booking_id = context.user_data['cancelling_booking_id']

    # Находим бронирование
    cursor = db.conn.cursor()
    cursor.execute('''
        SELECT b.*, u.first_name, u.last_name, u.telegram_id
        FROM bookings b 
        JOIN users u ON b.user_id = u.id 
        WHERE b.id = ?
    ''', (booking_id,))
    booking = cursor.fetchone()

    if not booking:
        await message_manager.send_message(update, context, "❌ Бронирование не найдено.", is_temporary=True)
        # ДОБАВЛЕНО: Возврат в главное меню
        await back_to_main_menu(update, context)
        return ConversationHandler.END

    # Отменяем бронирование
    cursor.execute('UPDATE bookings SET status = ? WHERE id = ?', ('cancelled', booking_id))
    db.conn.commit()

    # Уведомляем пользователя с причиной
    try:
        await context.bot.send_message(
            booking[9],  # user_telegram_id
            f"❌ Ваше бронирование отменено.\n\n"
            f"📅 Дата: {booking[2]}\n"
            f"⏰ Время: {booking[3]}\n"
            f"👥 Гостей: {booking[4]}\n\n"
            f"📝 Причина отмена: {reason}\n\n"
            f"Если у вас есть вопросы, свяжитесь с нами."
        )
    except Exception as e:
        logger.error(f"Не удалось уведомить пользователя: {e}")

    await message_manager.send_message(
        update, context,
        f"❌ Бронирование #{booking_id} отменено.\n"
        f"👤 Пользователь: {booking[7]} {booking[8]}\n"
        f"📝 Причина: {reason}",
        is_temporary=False
    )

    context.user_data.pop('cancelling_booking_id', None)

    # ДОБАВЛЕНО: Возврат в главное меню после успешной отмены
    await asyncio.sleep(2)  # Небольшая задержка для чтения сообщения
    await back_to_main_menu(update, context)

    return ConversationHandler.END


# ЗАПРОСЫ НА СПИСАНИЕ
async def handle_bonus_requests(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return

    # Очищаем только временные сообщения при переходе между разделами
    await message_manager.cleanup_user_messages(context, update.effective_user.id)

    requests = db.get_pending_requests()

    # ПОСТОЯННОЕ сообщение с меню управления запросами
    await message_manager.send_message(
        update, context,
        f"📋 Управление запросами на списание\n\n"
        f"📊 Найдено запросов: {len(requests) if requests else 0}\n\n"
        f"Для управления запросами используйте кнопки под сообщением.",
        reply_markup=get_admin_main_menu(),
        is_temporary=False
    )

    if not requests:
        # Временное сообщение - будет удалено
        await message_manager.send_message(
            update, context,
            "📭 Активных запросов на списание нет.",
            is_temporary=True
        )
        return

    # Каждый запрос - постоянное сообщение
    for request in requests:
        message = (
            f"🎁 Запрос на списание баллов\n\n"
            f"👤 Пользователь: {request[5]} {request[6]}\n"
            f"🆔 ID пользователя: {request[1]}\n"
            f"💰 Сумма: {request[2]} баллов\n"
            f"📅 Дата: {request[4]}\n"
            f"🆔 ID запроса: {request[0]}"
        )

        await message_manager.send_message(
            update, context,
            message,
            reply_markup=get_bonus_request_keyboard(request[0]),
            is_temporary=False
        )


async def refresh_bonus_requests(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обновить список запросов"""
    if not is_admin(update.effective_user.id):
        return

    # Очищаем все временные сообщения
    await message_manager.cleanup_user_messages(context, update.effective_user.id)

    # Вызываем основную функцию для показа запросов
    await handle_bonus_requests(update, context)


async def handle_bonus_request_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка действий с запросами на списание - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        return

    action, request_id = query.data.split('_')
    request_id = int(request_id)

    # Находим запрос
    requests = db.get_pending_requests()
    request_data = None
    for req in requests:
        if req[0] == request_id:
            request_data = req
            break

    if not request_data:
        try:
            await query.edit_message_text("❌ Запрос не найден.")
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение ошибки запроса не требует изменений")
            else:
                logger.error(f"Ошибка при обработке запроса на списание: {e}")
                await message_manager.send_message(
                    update, context,
                    "❌ Запрос не найден.",
                    is_temporary=True
                )
        return

    user_data = db.get_user_by_id(request_data[1])

    if action == 'approve':
        # Проверяем достаточно ли баллов
        if request_data[2] > user_data[5]:
            try:
                await query.edit_message_text("❌ У пользователя недостаточно баллов для списания.")
            except Exception as e:
                if "Message is not modified" in str(e):
                    logger.debug("Сообщение ошибки баллов не требует изменений")
                else:
                    logger.error(f"Ошибка при обработке запроса на списание: {e}")
                    await message_manager.send_message(
                        update, context,
                        "❌ У пользователя недостаточно баллов для списания.",
                        is_temporary=True
                    )
            return

        # Списание баллов
        db.update_user_balance(request_data[1], -request_data[2])
        db.update_bonus_request(request_id, 'approved')
        db.add_transaction(request_data[1], -request_data[2], 'spend', 'Списание по запросу')

        # Уведомляем пользователя
        try:
            await context.bot.send_message(
                user_data[1],
                f"✅ Ваш запрос на списание {request_data[2]} бонусных баллов одобрен!\n"
                f"💰 Новый баланс: {user_data[5] - request_data[2]} баллов"
            )
        except Exception as e:
            logger.error(f"Не удалось уведомить пользователя: {e}")

        try:
            await query.edit_message_text(
                f"✅ Запрос на списание {request_data[2]} баллов одобрен.\n"
                f"👤 Пользователь: {user_data[2]} {user_data[3]}"
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение одобрения запроса не требует изменений")
            else:
                logger.error(f"Ошибка при одобрении запроса на списание: {e}")
                await message_manager.send_message(
                    update, context,
                    f"✅ Запрос на списание {request_data[2]} баллов одобрен.\n👤 Пользователь: {user_data[2]} {user_data[3]}",
                    is_temporary=False
                )

    else:  # reject
        db.update_bonus_request(request_id, 'rejected')

        # Уведомляем пользователя
        try:
            await context.bot.send_message(
                user_data[1],
                f"❌ Ваш запрос на списание {request_data[2]} бонусных баллов отклонен.",
                is_temporary=True
            )
        except Exception as e:
            logger.error(f"Не удалось уведомить пользователя: {e}")

        try:
            await query.edit_message_text(
                f"❌ Запрос на списание {request_data[2]} баллов отклонен.\n"
                f"👤 Пользователь: {user_data[2]} {user_data[3]}"
            )
        except Exception as e:
            if "Message is not modified" in str(e):
                logger.debug("Сообщение отклонения запроса не требует изменений")
            else:
                logger.error(f"Ошибка при отклонении запроса на списание: {e}")
                await message_manager.send_message(
                    update, context,
                    f"❌ Запрос на списание {request_data[2]} баллов отклонен.\n👤 Пользователь: {user_data[2]} {user_data[3]}",
                    is_temporary=False
                )

    # После обработки запроса НЕ показываем новое меню, чтобы не перезаписывать существующее
    # Администратор уже имеет меню управления запросами


# РАССЫЛКА СООБЩЕНИЙ С МЕДИА
async def broadcast_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return

    # Очищаем только временные сообщения при переходе между разделами
    await message_manager.cleanup_user_messages(context, update.effective_user.id)

    context.user_data['awaiting_broadcast'] = True
    await message_manager.send_message(
        update, context,
        "📢 Рассылка сообщений\n\n"
        "Отправьте сообщение для рассылки (текст, фото, видео, документ или аудио):",
        reply_markup=get_cancel_keyboard(),
        is_temporary=False
    )
    return AWAITING_BROADCAST_MEDIA


async def process_broadcast_media(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.text == "❌ Отмена":
        context.user_data.pop('awaiting_broadcast', None)
        await message_manager.send_message(
            update, context,
            "❌ Рассылка отменена.",
            reply_markup=get_admin_main_menu(),
            is_temporary=True
        )
        return ConversationHandler.END

    if not is_admin(update.effective_user.id) or not context.user_data.get('awaiting_broadcast'):
        return

    # Получаем ВСЕХ пользователей
    all_users = db.get_all_users()

    if not all_users:
        await message_manager.send_message(
            update, context,
            "❌ В базе данных нет пользователей для рассылки.",
            reply_markup=get_admin_main_menu(),
            is_temporary=True
        )
        context.user_data.pop('awaiting_broadcast', None)
        return ConversationHandler.END

    # Функция 1: Проверяем доступность пользователей перед рассылкой
    await message_manager.send_message(
        update, context,
        f"🔍 Начинаю проверку доступности пользователей...\n"
        f"📊 Всего пользователей в базе: {len(all_users)}",
        is_temporary=True
    )

    available_users = []
    unavailable_users = []
    check_errors = []

    # Проверяем каждого пользователя
    for i, user in enumerate(all_users, 1):
        user_id = user[0]  # ID в базе данных
        telegram_id = user[1]  # Telegram ID
        first_name = user[2]
        last_name = user[3]

        # Показываем прогресс проверки каждые 10 пользователей
        if i % 10 == 0 or i == len(all_users):
            await message_manager.send_message(
                update, context,
                f"🔍 Проверено {i}/{len(all_users)} пользователей...",
                is_temporary=True
            )

        try:
            # Пробуем отправить действие "печатает" - проверка доступности
            await context.bot.send_chat_action(telegram_id, 'typing')
            available_users.append(user)
        except Exception as e:
            error_message = str(e)

            # Анализируем тип ошибки
            error_type = "Неизвестная ошибка"
            if "bot was blocked" in error_message.lower() or "bot blocked" in error_message.lower():
                error_type = "Пользователь заблокировал бота"
            elif "user not found" in error_message.lower():
                error_type = "Пользователь не найден"
            elif "chat not found" in error_message.lower():
                error_type = "Чат не найден"
            elif "forbidden" in error_message.lower():
                error_type = "Доступ запрещен"

            unavailable_users.append({
                'id': user_id,
                'telegram_id': telegram_id,
                'name': f"{first_name} {last_name}",
                'error_type': error_type,
                'error_details': error_message
            })
            logger.warning(f"Пользователь {telegram_id} недоступен: {error_type}")

    # Администраторы НЕ исключаются из списка получателей
    users_for_broadcast = available_users  # Включаем всех доступных пользователей

    if not users_for_broadcast:
        # Формируем отчет о проверке
        report_message = f"📊 Отчет проверки доступности пользователей:\n\n"
        report_message += f"👥 Всего пользователей в базе: {len(all_users)}\n"
        report_message += f"✅ Доступных пользователей: {len(available_users)}\n"
        report_message += f"❌ Недоступных пользователей: {len(unavailable_users)}\n\n"

        if unavailable_users:
            report_message += f"📋 Детали по недоступным пользователям:\n"
            for i, user in enumerate(unavailable_users[:5], 1):
                report_message += f"{i}. 👤 {user['name']} (ID: {user['id']})\n"
                report_message += f"   ❌ Тип ошибки: {user['error_type']}\n"

        report_message += f"\n💡 Рекомендации:\n"
        report_message += f"• Нет доступных пользователей для рассылки\n"
        report_message += f"• Проверьте список недоступных пользователей\n"
        report_message += f"• Убедитесь, что пользователи не заблокировали бота\n"

        await message_manager.send_message(
            update, context,
            report_message,
            reply_markup=get_admin_main_menu(),
            is_temporary=False
        )

        context.user_data.pop('awaiting_broadcast', None)
        return ConversationHandler.END

    # Начинаем рассылку (администраторы тоже получат сообщение)
    await message_manager.send_message(
        update, context,
        f"📨 Начинаю рассылку для {len(users_for_broadcast)} доступных пользователей...\n"
        f"ℹ️ Администраторы также получат сообщение.",
        is_temporary=True
    )

    success_count = 0
    failed_users = []  # Список для хранения информации о неудачных отправках
    send_errors_by_type = {}  # Группировка ошибок по типу
    admin_received = False  # Флаг получения администратором

    for i, user in enumerate(users_for_broadcast, 1):
        user_id = user[0]  # ID в базе данных
        telegram_id = user[1]  # Telegram ID
        first_name = user[2]
        last_name = user[3]
        is_admin_user = is_admin(telegram_id)  # Проверяем, является ли администратором

        # Показываем прогресс отправки каждые 10 пользователей
        if i % 10 == 0 or i == len(users_for_broadcast):
            progress_msg = f"📨 Отправлено {i}/{len(users_for_broadcast)} сообщений..."
            if is_admin_user:
                progress_msg += f"\n👨‍💼 Администратор {first_name} {last_name} получит сообщение"
            await message_manager.send_message(
                update, context,
                progress_msg,
                is_temporary=True
            )

        try:
            # Отправляем текст
            if update.message.text:
                await context.bot.send_message(
                    telegram_id,
                    f"📢 Сообщение от администратора:\n\n{update.message.text}"
                )

            # Отправляем фото
            if update.message.photo:
                await context.bot.send_photo(
                    telegram_id,
                    photo=update.message.photo[-1].file_id,
                    caption=update.message.caption if update.message.caption else "📢 Рассылка от администратора"
                )

            # Отправляем видео
            if update.message.video:
                await context.bot.send_video(
                    telegram_id,
                    video=update.message.video.file_id,
                    caption=update.message.caption if update.message.caption else "📢 Рассылка от администратора"
                )

            # Отправляем документ
            if update.message.document:
                await context.bot.send_document(
                    telegram_id,
                    document=update.message.document.file_id,
                    caption=update.message.caption if update.message.caption else "📢 Рассылка от администратора"
                )

            # Отправляем аудио
            if update.message.audio:
                await context.bot.send_audio(
                    telegram_id,
                    audio=update.message.audio.file_id,
                    caption=update.message.caption if update.message.caption else "📢 Рассылка от администратора"
                )

            success_count += 1

            # Отмечаем, если администратор получил сообщение
            if is_admin_user:
                admin_received = True
                logger.info(f"Администратор {first_name} {last_name} (ID: {user_id}) получил рассылку")

        except Exception as e:
            error_message = str(e)

            # Логируем отдельно для администраторов
            if is_admin_user:
                logger.error(f"Не удалось отправить рассылку администратору {telegram_id}: {error_message}")
            else:
                logger.error(f"Не удалось отправить сообщение пользователю {telegram_id}: {error_message}")

            # Анализируем тип ошибки
            error_type = "Неизвестная ошибка"
            if "bot was blocked" in error_message.lower():
                error_type = "Пользователь заблокировал бота"
            elif "user not found" in error_message.lower():
                error_type = "Пользователь не найден"
            elif "chat not found" in error_message.lower():
                error_type = "Чат не найден"
            elif "forbidden" in error_message.lower():
                error_type = "Доступ запрещен"
            elif "flood" in error_message.lower():
                error_type = "Превышен лимит отправки"
            elif "too many requests" in error_message.lower():
                error_type = "Слишком много запросов"

            # Группируем ошибки по типу для статистики
            if error_type not in send_errors_by_type:
                send_errors_by_type[error_type] = 0
            send_errors_by_type[error_type] += 1

            # Отмечаем, если это ошибка администратора
            user_type = "👤 Пользователь"
            if is_admin_user:
                user_type = "👨‍💼 Администратор"

            # Сохраняем информацию о пользователе, которому не удалось отправить
            failed_users.append({
                'id': user_id,
                'telegram_id': telegram_id,
                'name': f"{first_name} {last_name}",
                'type': user_type,
                'error_type': error_type,
                'error_details': error_message[:100]  # Обрезаем длинные ошибки
            })

    # Формируем детальный финальный отчет
    message = "✅ РАССЫЛКА ЗАВЕРШЕНА\n\n"

    # Функция 2: Детальная статистика по недоступным пользователям
    message += "📊 ПОДРОБНАЯ СТАТИСТИКА:\n"
    message += f"• 👥 Всего пользователей в базе: {len(all_users)}\n"
    message += f"• ✅ Доступных для проверки: {len(available_users)}\n"
    message += f"• ❌ Недоступных при проверке: {len(unavailable_users)}\n"
    message += f"• 📨 Получателей рассылки: {len(users_for_broadcast)}\n"
    message += f"• 🎯 Успешно доставлено: {success_count}\n"
    message += f"• ⚠️  Ошибок при отправке: {len(failed_users)}\n"

    # Информация об администраторах
    admin_count = sum(1 for user in users_for_broadcast if is_admin(user[1]))
    admin_success = admin_count - sum(1 for failed in failed_users if failed['type'] == "👨‍💼 Администратор")

    if admin_count > 0:
        message += f"• 👨‍💼 Администраторов в рассылке: {admin_count}\n"
        message += f"• ✅ Администраторов получило: {admin_success}\n\n"
    else:
        message += "\n"

    # Функция 3: Показываем конкретные ошибки для каждой неудачной отправки
    if failed_users:
        message += "📋 ОШИБКИ ПРИ ОТПРАВКЕ:\n"

        # Статистика по типам ошибок
        if send_errors_by_type:
            message += "📈 Распределение ошибок по типам:\n"
            for error_type, count in send_errors_by_type.items():
                message += f"  • {error_type}: {count}\n"
            message += "\n"

        # Разделяем ошибки администраторов и пользователей
        admin_errors = [f for f in failed_users if f['type'] == "👨‍💼 Администратор"]
        user_errors = [f for f in failed_users if f['type'] == "👤 Пользователь"]

        if admin_errors:
            message += "👨‍💼 Ошибки администраторов:\n"
            for i, failed in enumerate(admin_errors[:3], 1):
                message += f"{i}. {failed['name']} (ID: {failed['id']})\n"
                message += f"   ❌ Тип: {failed['error_type']}\n"
                if len(failed['error_details']) > 0:
                    message += f"   📝 Детали: {failed['error_details']}\n"
            if len(admin_errors) > 3:
                message += f"... и еще {len(admin_errors) - 3} ошибок администраторов\n"
            message += "\n"

        if user_errors:
            message += "👤 Ошибки пользователей (первые 5):\n"
            for i, failed in enumerate(user_errors[:5], 1):
                message += f"{i}. {failed['name']} (ID: {failed['id']})\n"
                message += f"   ❌ Тип: {failed['error_type']}\n"
                if len(failed['error_details']) > 0:
                    message += f"   📝 Детали: {failed['error_details']}\n"

            if len(user_errors) > 5:
                message += f"... и еще {len(user_errors) - 5} ошибок пользователей\n\n"
            else:
                message += "\n"

    # Статистика по недоступным пользователям (из проверки)
    if unavailable_users:
        message += "📋 НЕДОСТУПНЫЕ ПОЛЬЗОВАТЕЛИ (при проверке):\n"

        # Группируем по типам ошибок
        error_groups = {}
        for user in unavailable_users:
            error_type = user['error_type']
            if error_type not in error_groups:
                error_groups[error_type] = []
            error_groups[error_type].append(user)

        for error_type, users in error_groups.items():
            message += f"• {error_type}: {len(users)} пользователей\n"

        # Показываем примеры
        message += "\n👁️ Примеры недоступных пользователей:\n"
        for i, user in enumerate(unavailable_users[:3], 1):
            message += f"{i}. {user['name']} (ID: {user['id']}) - {user['error_type']}\n"

        if len(unavailable_users) > 3:
            message += f"... и еще {len(unavailable_users) - 3} пользователей\n\n"
        else:
            message += "\n"

    # Функция 4: Даем рекомендации по дальнейшим действиям
    message += "💡 РЕКОМЕНДАЦИИ:\n"

    if len(failed_users) > 0:
        message += "• Проверьте пользователей с ошибками отправки\n"
        message += "• Попробуйте отправить им сообщение вручную\n"

        # Специфичные рекомендации для администраторов
        admin_errors_count = len([f for f in failed_users if f['type'] == "👨‍💼 Администратор"])
        if admin_errors_count > 0:
            message += "• ⚠️ Администраторы не получили сообщение. Проверьте их настройки\n"

    if len(unavailable_users) > 0:
        message += "• Рассмотрите удаление недоступных пользователей из базы\n"
        message += f"• Всего недоступных: {len(unavailable_users)} пользователей\n"

    if success_count == len(users_for_broadcast):
        message += "• Отличный результат! Все сообщения доставлены\n"
        if admin_received:
            message += "• Администраторы также получили сообщение\n"

    if len(failed_users) > len(users_for_broadcast) / 2:
        message += "• ⚠️ Много ошибок. Проверьте настройки бота и лимиты Telegram\n"

    # Дополнительные метрики эффективности
    delivery_rate = (success_count / len(users_for_broadcast) * 100) if users_for_broadcast else 0
    message += f"\n📈 Эффективность рассылки: {delivery_rate:.1f}% успешных отправок\n"

    if delivery_rate < 50:
        message += "⚠️ Низкая эффективность. Рекомендуется проверить базу пользователей\n"
    elif delivery_rate > 90:
        message += "✅ Отличная эффективность рассылки!\n"
        if admin_received:
            message += "✅ Администраторы получили сообщение\n"

    # Сохраняем детальные данные для возможного экспорта или анализа
    context.user_data['broadcast_details'] = {
        'total_users': len(all_users),
        'available_count': len(available_users),
        'unavailable_count': len(unavailable_users),
        'sent_count': len(users_for_broadcast),
        'success_count': success_count,
        'failed_count': len(failed_users),
        'delivery_rate': delivery_rate,
        'admin_included': True,  # Флаг включения администраторов
        'admin_received': admin_received,
        'admin_count': admin_count,
        'admin_success': admin_success,
        'unavailable_users': unavailable_users,
        'failed_users': failed_users,
        'error_stats': send_errors_by_type,
        'message_content': update.message.text or "Медиа-сообщение",
        'timestamp': db.get_moscow_time()
    }

    await message_manager.send_message(
        update, context,
        message,
        reply_markup=get_admin_main_menu(),
        is_temporary=False
    )

    # Логируем итоги рассылки
    logger.info(
        f"Рассылка завершена. "
        f"Всего: {len(all_users)}, "
        f"Доступно: {len(available_users)}, "
        f"Отправлено: {len(users_for_broadcast)}, "
        f"Успешно: {success_count}, "
        f"Ошибок: {len(failed_users)}, "
        f"Администраторов: {admin_count}, "
        f"Админ получили: {admin_success}, "
        f"Эффективность: {delivery_rate:.1f}%"
    )

    context.user_data.pop('awaiting_broadcast', None)
    return ConversationHandler.END


# ЛИЧНЫЕ СООБЩЕНИЯ ПОЛЬЗОВАТЕЛЯМ
async def start_user_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return

    # Очищаем только временные сообщения при переходе между разделами
    await message_manager.cleanup_user_messages(context, update.effective_user.id)

    users = db.get_all_users()

    if not users:
        await message_manager.send_message(update, context, "📭 Пользователи не найдены.", is_temporary=True)
        return

    await message_manager.send_message(
        update, context,
        "✉️ Выберите пользователя для отправки сообщения:",
        reply_markup=get_users_keyboard(users),
        is_temporary=False
    )
    return SELECTING_USER


async def user_selected_for_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка выбора пользователя для сообщения - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        return

    user_id = int(query.data.split('_')[-1])
    context.user_data['selected_user_id'] = user_id
    user_data = db.get_user_by_id(user_id)

    try:
        await query.edit_message_text(
            f"✉️ Отправка сообщения пользователю:\n"
            f"👤 {user_data[2]} {user_data[3]}\n"
            f"📱 {user_data[4]}\n\n"
            f"Введите сообщение:",
            reply_markup=get_cancel_keyboard()
        )
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение выбора пользователя не требует изменений")
        else:
            logger.error(f"Ошибка при выборе пользователя для сообщения: {e}")
            await message_manager.send_message(
                update, context,
                f"✉️ Отправка сообщения пользователю:\n👤 {user_data[2]} {user_data[3]}\n📱 {user_data[4]}\n\nВведите сообщение:",
                reply_markup=get_cancel_keyboard(),
                is_temporary=False
            )
    return AWAITING_USER_MESSAGE


async def process_user_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.text == "❌ Отмена":
        context.user_data.pop('selected_user_id', None)
        await message_manager.send_message(
            update, context,
            "❌ Отправка сообщения отменена.",
            reply_markup=get_admin_main_menu(),
            is_temporary=True
        )
        return ConversationHandler.END

    if not is_admin(update.effective_user.id) or 'selected_user_id' not in context.user_data:
        return

    user_id = context.user_data['selected_user_id']
    user_data = db.get_user_by_id(user_id)
    message_text = update.message.text

    try:
        await context.bot.send_message(
            user_data[1],
            f"✉️ Сообщение от администратора:\n\n{message_text}"
        )
        await message_manager.send_message(
            update, context,
            f"✅ Сообщение отправлено пользователю:\n"
            f"👤 {user_data[2]} {user_data[3]}",
            reply_markup=get_admin_main_menu(),
            is_temporary=False
        )
    except Exception as e:
        logger.error(f"Не удалось отправить сообщение пользователю {user_data[1]}: {e}")
        await message_manager.send_message(
            update, context,
            f"❌ Не удалось отправить сообщение пользователю {user_data[2]} {user_data[3]}",
            reply_markup=get_admin_main_menu(),
            is_temporary=True
        )

    context.user_data.pop('selected_user_id', None)
    return ConversationHandler.END


# НАЧИСЛЕНИЕ БАЛЛОВ (5% от суммы)
async def add_bonus_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        return

    user_id = int(query.data.split('_')[-1])
    context.user_data['selected_user'] = user_id
    context.user_data['action'] = 'add_bonus_percent'

    user_data = db.get_user_by_id(user_id)

    await message_manager.send_message(
        update, context,
        f"💰 Начисление баллов пользователю:\n"
        f"👤 {user_data[2]} {user_data[3]}\n"
        f"💰 Текущий баланс: {user_data[5]} баллов\n\n"
        f"Введите сумму, которую потратил пользователь (рубли):",
        reply_markup=get_cancel_keyboard(),
        is_temporary=False
    )
    return AWAITING_SPENT_AMOUNT


async def process_spent_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.text == "❌ Отмена":
        context.user_data.clear()
        await message_manager.send_message(
            update, context,
            "❌ Операция отменена.",
            reply_markup=get_admin_main_menu(),
            is_temporary=True
        )
        return ConversationHandler.END

    if not is_admin(update.effective_user.id):
        return

    try:
        spent_amount = int(update.message.text)
        user_id = context.user_data.get('selected_user')
        action = context.user_data.get('action')

        if spent_amount <= 0:
            await message_manager.send_message(
                update, context,
                "❌ Сумма должна быть положительной.",
                is_temporary=True
            )
            return AWAITING_SPENT_AMOUNT

        user_data = db.get_user_by_id(user_id)

        if action == 'add_bonus_percent':
            # Начисляем 5% от суммы
            bonus_amount = int(spent_amount * 0.05)
            db.update_user_balance(user_id, bonus_amount)
            db.add_transaction(user_id, bonus_amount, 'earn', f'Начисление 5% от суммы {spent_amount} руб')

            # Уведомляем пользователя о начислении
            try:
                await context.bot.send_message(
                    user_data[1],  # telegram_id пользователя
                    f"🎉 Вам начислены бонусные баллы!\n\n"
                    f"💰 Начислено: {bonus_amount} баллов (5% от {spent_amount} руб)\n"
                    f"💳 Новый баланс: {user_data[5] + bonus_amount} баллов\n\n"
                    f"Мы будем рады если вы оставите свой отзыв:\n"
                    f"📍 [Оставить отзыв на Яндекс Картах](https://yandex.ru/maps/org/vovsetyazhkiye/57633254342)\n\n"
                    f"Спасибо за посещение нашего заведения! 🏪",
                    parse_mode='Markdown'
                )
            except Exception as e:
                logger.error(f"Не удалось уведомить пользователя о начислении: {e}")

            await message_manager.send_message(
                update, context,
                f"✅ Пользователю {user_data[2]} {user_data[3]} начислено {bonus_amount} бонусных баллов (5% от {spent_amount} руб).\n"
                f"💰 Новый баланс: {user_data[5] + bonus_amount} баллов",
                reply_markup=get_admin_main_menu(),
                is_temporary=False
            )

        context.user_data.clear()
        return ConversationHandler.END

    except ValueError:
        await message_manager.send_message(
            update, context,
            "❌ Пожалуйста, введите корректную сумму:",
            is_temporary=True
        )
        return AWAITING_SPENT_AMOUNT


# СПИСАНИЕ БАЛЛОВ АДМИНИСТРАТОРОМ
async def remove_bonus_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        return

    user_id = int(query.data.split('_')[-1])
    context.user_data['selected_user'] = user_id
    context.user_data['action'] = 'remove_bonus'

    user_data = db.get_user_by_id(user_id)

    await message_manager.send_message(
        update, context,
        f"📊 Списание баллов у пользователя:\n"
        f"👤 {user_data[2]} {user_data[3]}\n"
        f"💰 Текущий баланс: {user_data[5]} баллов\n\n"
        f"Введите сумму для списания:",
        reply_markup=get_cancel_keyboard(),
        is_temporary=False
    )
    return AWAITING_BONUS_AMOUNT


async def process_remove_bonus(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.text == "❌ Отмена":
        context.user_data.clear()
        await message_manager.send_message(
            update, context,
            "❌ Операция отменена.",
            reply_markup=get_admin_main_menu(),
            is_temporary=True
        )
        return ConversationHandler.END

    if not is_admin(update.effective_user.id):
        return

    try:
        amount = int(update.message.text)
        user_id = context.user_data.get('selected_user')

        if amount <= 0:
            await message_manager.send_message(
                update, context,
                "❌ Сумма должна быть положительной.",
                is_temporary=True
            )
            return AWAITING_BONUS_AMOUNT

        user_data = db.get_user_by_id(user_id)

        if amount > user_data[5]:
            await message_manager.send_message(
                update, context,
                "❌ Недостаточно баллов для списания.",
                is_temporary=True
            )
            return AWAITING_BONUS_AMOUNT

        db.update_user_balance(user_id, -amount)
        db.add_transaction(user_id, -amount, 'spend', 'Списание администратором')

        # Уведомляем пользователя о списании
        try:
            await context.bot.send_message(
                user_data[1],
                f"📊 С вашего счета списано {amount} бонусных баллов.\n"
                f"💰 Новый баланс: {user_data[5] - amount} баллов"
            )
        except Exception as e:
            logger.error(f"Не удалось уведомить пользователя о списании: {e}")

        await message_manager.send_message(
            update, context,
            f"✅ У пользователя {user_data[2]} {user_data[3]} списано {amount} бонусных баллов.\n"
            f"💰 Новый баланс: {user_data[5] - amount} баллов",
            reply_markup=get_admin_main_menu(),
            is_temporary=False
        )

        context.user_data.clear()
        return ConversationHandler.END

    except ValueError:
        await message_manager.send_message(
            update, context,
            "❌ Пожалуйста, введите корректное число:",
            is_temporary=True
        )
        return AWAITING_BONUS_AMOUNT


# СТАТИСТИКА
async def show_statistics(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return

    # Очищаем только временные сообщения при переходе между разделами
    await message_manager.cleanup_user_messages(context, update.effective_user.id)

    users = db.get_all_users()
    total_users = len(users)
    total_bonuses = sum(user[5] for user in users)

    # Получаем статистику бронирований
    booking_stats = db.get_booking_stats()

    # Получаем статистику запросов
    requests = db.get_pending_requests()
    pending_requests_count = len(requests)

    message = (
        f"📊 Статистика системы:\n\n"
        f"👥 Всего пользователей: {total_users}\n"
        f"💰 Всего бонусных баллов: {total_bonuses}\n"
        f"🏆 Средний баланс: {total_bonuses // total_users if total_users > 0 else 0} баллов\n\n"
        f"📅 Бронирования:\n"
        f"⏳ Ожидающие: {booking_stats.get('pending', 0)}\n"
        f"✅ Подтвержденные: {booking_stats.get('confirmed', 0)}\n"
        f"❌ Отмененные: {booking_stats.get('cancelled', 0)}\n\n"
        f"📋 Запросы на списание: {pending_requests_count}"
    )

    # Статистика - постоянное сообщение
    await message_manager.send_message(
        update, context,
        message,
        reply_markup=get_admin_main_menu(),
        is_temporary=False
    )


async def back_to_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Возврат в главное меню администратора с полной очисткой чата"""
    user = update.effective_user
    if not is_admin(user.id):
        return

    try:
        # ПОЛНАЯ ОЧИСТКА всех сообщений при возврате в главное меню
        await message_manager.cleanup_all_messages(context, user.id)

        # Небольшая задержка для завершения очистки
        await asyncio.sleep(0.5)

        # Показываем главное меню администратора
        await message_manager.send_message(
            update, context,
            "👨‍💼 Панель администратора",
            reply_markup=get_admin_main_menu(),
            is_temporary=False  # ГЛАВНОЕ МЕНЮ - ПОСТОЯННОЕ
        )

        # Логируем действие
        from error_logger import log_admin_action
        log_admin_action("Возврат в главное меню", user.id)

    except Exception as e:
        logger.error(f"Ошибка при возврате в главное меню администратора: {e}")
        # В случае ошибки все равно пытаемся показать меню
        await message_manager.send_message(
            update, context,
            "👨‍💼 Панель администратора",
            reply_markup=get_admin_main_menu(),
            is_temporary=False
        )


async def back_to_booking_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Вернуться в меню фильтрации бронирований"""
    if not is_admin(update.effective_user.id):
        return

    await show_bookings(update, context)
    return ConversationHandler.END


async def cancel_operation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    await message_manager.send_message(
        update, context,
        "❌ Операция отменена.",
        reply_markup=get_admin_main_menu(),
        is_temporary=True
    )
    return ConversationHandler.END


# ОБРАБОТЧИКИ CALLBACK
async def message_user_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка кнопки отправки сообщения пользователю - ИСПРАВЛЕННАЯ ВЕРСИЯ"""
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        return

    user_id = int(query.data.split('_')[-1])
    context.user_data['selected_user_id'] = user_id
    user_data = db.get_user_by_id(user_id)

    try:
        await query.edit_message_text(
            f"✉️ Отправка сообщения пользователю:\n"
            f"👤 {user_data[2]} {user_data[3]}\n"
            f"📱 {user_data[4]}\n\n"
            f"Введите сообщение:",
            reply_markup=get_cancel_keyboard()
        )
    except Exception as e:
        if "Message is not modified" in str(e):
            logger.debug("Сообщение отправки сообщения не требует изменений")
        else:
            logger.error(f"Ошибка при отправке сообщения пользователю: {e}")
            await message_manager.send_message(
                update, context,
                f"✉️ Отправка сообщения пользователю:\n👤 {user_data[2]} {user_data[3]}\n📱 {user_data[4]}\n\nВведите сообщение:",
                reply_markup=get_cancel_keyboard(),
                is_temporary=False
            )
    return AWAITING_USER_MESSAGE


# Создаем обработчики
def get_broadcast_handler():
    return ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^📢 Рассылка$"), broadcast_message)],
        states={
            AWAITING_BROADCAST_MEDIA: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, process_broadcast_media),
                MessageHandler(filters.PHOTO | filters.VIDEO | filters.Document.ALL | filters.AUDIO,
                               process_broadcast_media)
            ]
        },
        fallbacks=[MessageHandler(filters.Regex("^❌ Отмена$"), cancel_operation)]
    )


def get_user_message_handler():
    return ConversationHandler(
        entry_points=[
            MessageHandler(filters.Regex("^✉️ Написать пользователю$"), start_user_message),
            CallbackQueryHandler(message_user_callback, pattern="^message_")
        ],
        states={
            SELECTING_USER: [CallbackQueryHandler(user_selected_for_message, pattern="^select_user_")],
            AWAITING_USER_MESSAGE: [MessageHandler(filters.TEXT & ~filters.COMMAND, process_user_message)]
        },
        fallbacks=[MessageHandler(filters.Regex("^❌ Отмена$"), cancel_operation)]
    )


def get_bonus_handler():
    return ConversationHandler(
        entry_points=[
            CallbackQueryHandler(add_bonus_callback, pattern="^add_bonus_"),
            CallbackQueryHandler(remove_bonus_callback, pattern="^remove_bonus_")
        ],
        states={
            AWAITING_BONUS_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, process_remove_bonus)],
            AWAITING_SPENT_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, process_spent_amount)]
        },
        fallbacks=[MessageHandler(filters.Regex("^❌ Отмена$"), cancel_operation)]
    )


def get_booking_date_handler():
    return ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^📅 По дате$"), show_dates_for_filter)],
        states={
            SELECTING_YEAR: [MessageHandler(filters.TEXT & ~filters.COMMAND, select_year_for_filter)],
            SELECTING_MONTH: [MessageHandler(filters.TEXT & ~filters.COMMAND, select_month_for_filter)],
            SELECTING_DATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, show_bookings_by_selected_date)]
        },
        fallbacks=[MessageHandler(filters.Regex("^❌ Отмена$"), back_to_booking_menu)]
    )


def get_booking_cancellation_handler():
    return ConversationHandler(
        entry_points=[
            CallbackQueryHandler(handle_booking_cancellation_with_reason, pattern="^cancel_booking_reason_")
        ],
        states={
            AWAITING_CANCELLATION_REASON: [MessageHandler(filters.TEXT & ~filters.COMMAND, process_cancellation_reason)]
        },
        fallbacks=[MessageHandler(filters.Regex("^❌ Отмена$"), cancel_operation)]
    )

# НОВЫЙ ОБРАБОТЧИК ДЛЯ ПОИСКА ПОЛЬЗОВАТЕЛЕЙ
def get_user_search_handler():
    return ConversationHandler(
        entry_points=[
            CallbackQueryHandler(start_user_search, pattern="^search_user$"),
        ],
        states={
            AWAITING_SEARCH_QUERY: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, process_user_search),
                CallbackQueryHandler(cancel_search, pattern="^cancel_search$")
            ]
        },
        fallbacks=[
            MessageHandler(filters.Regex("^❌ Отмена$"), cancel_search),
            CallbackQueryHandler(back_to_users_list, pattern="^back_to_users_list$")
        ]
    )


# ========== ФУНКЦИИ ДЛЯ РЕЖИМА ПОИСКА ПОЛЬЗОВАТЕЛЕЙ ==========

async def exit_search_mode(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Выйти из режима поиска пользователей"""
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        return

    # Сбрасываем режим поиска
    context.user_data.pop('search_users_mode', None)

    # Возвращаемся в главное меню админа
    await back_to_main_menu(update, context)


async def show_full_users_list(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать полный список пользователей"""
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        return

    # Получаем номер страницы из callback_data
    page = 0
    if query.data.startswith("show_full_users_list_"):
        try:
            page = int(query.data.split("_")[-1])
        except:
            page = 0

    # Сбрасываем режим поиска (теперь показываем список)
    context.user_data.pop('search_users_mode', None)

    # Вызываем оригинальную логику show_users_list для показа списка
    users = db.get_all_users()

    if not users:
        await query.edit_message_text("📭 Пользователи не найдены.")
        return

    # Пагинация - 20 пользователей на страницу
    users_per_page = 20
    total_pages = (len(users) + users_per_page - 1) // users_per_page

    # Проверяем валидность страницы
    if page < 0:
        page = 0
    elif page >= total_pages:
        page = total_pages - 1

    start_index = page * users_per_page
    end_index = min(start_index + users_per_page, len(users))
    users_page = users[start_index:end_index]

    message = f"👥 Список пользователей (стр. {page + 1}/{total_pages}, всего: {len(users)})\n\n"
    message += "Выберите пользователя:"

    # Создаем клавиатуру с пагинацией
    keyboard = []

    # Добавляем кнопки навигации
    nav_buttons = []
    if page > 0:
        nav_buttons.append(InlineKeyboardButton("⬅️ Предыдущая", callback_data=f"show_full_users_list_{page - 1}"))
    if page < total_pages - 1:
        nav_buttons.append(InlineKeyboardButton("Следующая ➡️", callback_data=f"show_full_users_list_{page + 1}"))

    if nav_buttons:
        keyboard.append(nav_buttons)

    # Добавляем кнопки пользователей
    for user in users_page:
        keyboard.append([InlineKeyboardButton(
            f"{user[2]} {user[3]} (ID: {user[0]}) | 💰 {user[5]} баллов",
            callback_data=f"select_user_{user[0]}"
        )])

    # Добавляем кнопки управления
    keyboard.append([InlineKeyboardButton("🔄 Обновить", callback_data="refresh_users")])
    keyboard.append([InlineKeyboardButton("🔍 Вернуться к поиску", callback_data="back_to_search_mode")])
    keyboard.append([InlineKeyboardButton("❌ Выйти из поиска", callback_data="exit_search_mode")])

    reply_markup = InlineKeyboardMarkup(keyboard)

    # Редактируем текущее сообщение
    await query.edit_message_text(
        message,
        reply_markup=reply_markup
    )


async def back_to_search_mode(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Вернуться в режим поиска"""
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        return

    # Снова включаем режим поиска
    context.user_data['search_users_mode'] = True

    await query.edit_message_text(
        "🔍 Режим поиска пользователей активен!\n\n"
        "📌 Просто напишите в чат:\n"
        "• ID пользователя (например: 123)\n"
        "• Имя или фамилию (например: Иван)\n"
        "• Часть имени\n\n"
        "Или нажмите кнопку для просмотра полного списка:",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("📋 Показать полный список", callback_data="show_full_users_list_0")],
            [InlineKeyboardButton("❌ Выйти из поиска", callback_data="exit_search_mode")]
        ])
    )


async def new_search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Начать новый поиск"""
    query = update.callback_query
    await query.answer()

    if not is_admin(query.from_user.id):
        return

    # Снова включаем режим поиска
    context.user_data['search_users_mode'] = True

    await query.edit_message_text(
        "🔍 Введите новый поисковый запрос:\n"
        "• ID пользователя\n"
        "• Имя или фамилию\n"
        "• Часть имени\n\n"
        "Или нажмите кнопку для просмотра полного списка:",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("📋 Показать полный список", callback_data="show_full_users_list_0")],
            [InlineKeyboardButton("❌ Выйти из поиска", callback_data="exit_search_mode")]
        ])
    )


async def reset_shift_data(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Сбросить данные смены в памяти"""
    if not is_admin(update.effective_user.id):
        return

    # Сброс данных в памяти
    context.bot_data.clear()

    await update.message.reply_text("✅ Данные смены в памяти сброшены! Бот нужно перезапустить.")