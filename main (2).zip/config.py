import os
from dotenv import load_dotenv

# Загружаем переменные из .env
load_dotenv()

# Получаем токен из .env
BOT_TOKEN = os.getenv('BOT_TOKEN')

# Для отладки - покажем что загрузилось
print(f"🔐 DEBUG: Загружен токен: {BOT_TOKEN[:10]}..." if BOT_TOKEN else "❌ DEBUG: Токен не загружен")

# Если токен не загружен, попробуем другие способы
if not BOT_TOKEN:
    # Попробуем загрузить напрямую из переменных окружения
    BOT_TOKEN = os.environ.get('BOT_TOKEN')
    print(f"🔐 DEBUG: Токен из environ: {BOT_TOKEN[:10]}..." if BOT_TOKEN else "❌ DEBUG: Токен не найден в environ")

# Если все еще нет токена, используем прямое указание
if not BOT_TOKEN:
    # ⚠️ ВРЕМЕННО: вставьте ваш токен здесь
    BOT_TOKEN = "8432245471:AAGhfcc2GhxI2kaE7Ab29azAngZTeXGYicg"
    print("⚠️ DEBUG: Используется временный токен")

# Администраторы бота
ADMIN_IDS = [356633485, 484893578]  # ⚠️ Добавлен второй администратор

# Настройки бонусов
WELCOME_BONUS = 100
BONUS_PERCENTAGE = 5
REFERRAL_BONUS = 25  # Бонус за приглашенного пользователя

# Настройки базы данных
DB_NAME = 'loyalty_bot.db'

# Настройки очистки сообщений
MESSAGE_CLEANUP_DELAY = 10  # секунды для временных сообщений (увеличено)

# Настройки логирования
LOG_FILE = 'bot_errors.log'

# Проверка наличия токена
if not BOT_TOKEN:
    raise ValueError("❌ Токен бота не найден!")
else:
    print(f"✅ Токен успешно загружен: {BOT_TOKEN[:10]}...")