# fix_categories.py
from database import Database


def fix_menu_categories():
    """Исправить категории для позиций меню"""
    db = Database()
    cursor = db.conn.cursor()

    print("🔄 Исправление категорий в меню...")

    # Список позиций для исправления
    corrections = [
        ("Смородиновый", "Чай"),
        ("Клубничный", "Чай"),
        ("Марокканский", "Чай"),
        ("Голубика", "Чай"),
        ("Пиво/Энергетик", "Напитки")
    ]

    fixed_count = 0
    for item_name, correct_category in corrections:
        try:
            # Проверяем текущую категорию
            cursor.execute('SELECT category FROM menu_items WHERE name = ?', (item_name,))
            result = cursor.fetchone()

            if result:
                current_category = result[0]
                if current_category != correct_category:
                    cursor.execute(
                        'UPDATE menu_items SET category = ? WHERE name = ?',
                        (correct_category, item_name)
                    )
                    print(f"✅ Исправлено: {item_name} - было '{current_category}', стало '{correct_category}'")
                    fixed_count += 1
                else:
                    print(f"✅ Уже правильно: {item_name} - '{correct_category}'")
            else:
                print(f"❌ Позиция не найдена: {item_name}")

        except Exception as e:
            print(f"❌ Ошибка с {item_name}: {e}")

    db.conn.commit()
    print(f"\n🎯 Исправлено {fixed_count} позиций")


def check_current_categories():
    """Проверить текущие категории проблемных позиций"""
    db = Database()
    cursor = db.conn.cursor()

    print("\n🔍 Текущие категории проблемных позиций:")
    print("=" * 50)

    problem_items = ["Смородиновый", "Клубничный", "Марокканский", "Голубика", "Пиво/Энергетик"]

    for item_name in problem_items:
        cursor.execute('SELECT name, category FROM menu_items WHERE name = ?', (item_name,))
        result = cursor.fetchone()
        if result:
            name, category = result
            print(f"  {name}: '{category}'")
        else:
            print(f"  {item_name}: ❌ НЕ НАЙДЕН")


def repopulate_menu_completely():
    """Полностью перезаполнить меню с правильными категориями"""
    db = Database()
    cursor = db.conn.cursor()

    print("🔄 Полное обновление меню с правильными категориями...")

    # Очищаем таблицу
    cursor.execute('DELETE FROM menu_items')
    print("✅ Таблица очищена")

    # Все позиции меню с ПРАВИЛЬНЫМИ категориями
    all_menu_items = [
        # Кальяны
        ('Пенсионный', 800, 'Кальяны'),
        ('Стандарт', 1000, 'Кальяны'),
        ('Премиум', 1200, 'Кальяны'),
        ('Фруктовая чаша', 1500, 'Кальяны'),
        ('Сигарный', 1500, 'Кальяны'),
        ('Парфюм', 2000, 'Кальяны'),

        # Напитки
        ('Вода', 100, 'Напитки'),
        ('Кола 0,5л', 100, 'Напитки'),
        ('Кола/Фанта/Спрайт 1л', 200, 'Напитки'),
        ('Пиво/Энергетик', 200, 'Напитки'),  # ПРАВИЛЬНАЯ категория

        # Коктейли
        ('В/кола', 400, 'Коктейли'),
        ('Санрайз', 400, 'Коктейли'),
        ('Лагуна', 400, 'Коктейли'),
        ('Фиеро', 400, 'Коктейли'),
        ('Пробирки', 600, 'Коктейли'),

        # Чай
        ("Да Хун Пао", 400, "Чай"),
        ("Те Гуань Инь", 400, "Чай"),
        ("Шу пуэр", 400, "Чай"),
        ("Сяо Чжун", 400, "Чай"),
        ("Юэ Гуан Бай", 400, "Чай"),
        ("Габа", 400, "Чай"),
        ("Гречишный", 400, "Чай"),
        ("Медовая дыня", 400, "Чай"),
        ("Малина/Мята", 400, "Чай"),
        ("Наглый фрукт", 400, "Чай"),
        ("Вишневый пуэр", 500, "Чай"),
        ("Марокканский", 500, "Чай"),  # ПРАВИЛЬНАЯ категория
        ("Голубика", 500, "Чай"),  # ПРАВИЛЬНАЯ категория
        ("Смородиновый", 500, "Чай"),  # ПРАВИЛЬНАЯ категория
        ("Клубничный", 500, "Чай"),  # ПРАВИЛЬНАЯ категория
        ("Облепиховый", 500, "Чай")
    ]

    # Добавляем все позиции
    for name, price, category in all_menu_items:
        try:
            cursor.execute(
                'INSERT INTO menu_items (name, price, category) VALUES (?, ?, ?)',
                (name, price, category)
            )
            print(f"✅ Добавлено: {name} - {price}₽ ({category})")
        except Exception as e:
            print(f"❌ Ошибка с {name}: {e}")

    db.conn.commit()
    print(f"✅ Добавлено {len(all_menu_items)} позиций в меню")


if __name__ == "__main__":
    print("Выберите действие:")
    print("1 - Проверить текущие категории")
    print("2 - Исправить только категории проблемных позиций")
    print("3 - Полностью перезаполнить меню (рекомендуется)")

    choice = input("Введите 1, 2 или 3: ")

    if choice == "1":
        check_current_categories()
    elif choice == "2":
        fix_menu_categories()
    elif choice == "3":
        repopulate_menu_completely()
    else:
        print("❌ Неверный выбор")