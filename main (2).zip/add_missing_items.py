2# add_missing_items.py
from database import Database


def add_missing_hookahs():
    """Добавить отсутствующие кальяны в базу"""
    db = Database()
    cursor = db.conn.cursor()

    # Все кальяны которые должны быть
    hookahs_to_add = [
        ('Пенсионный', 800, 'Кальяны'),
        ('Стандарт', 1000, 'Кальяны'),
        ('Премиум', 1200, 'Кальяны'),
        ('Фруктовая чаша', 1500, 'Кальяны'),
        ('Сигарный', 1500, 'Кальяны'),
        ('Парфюм', 2000, 'Кальяны')
    ]

    print("🔄 Добавление отсутствующих кальянов...")

    added_count = 0
    for name, price, category in hookahs_to_add:
        try:
            cursor.execute(
                'INSERT INTO menu_items (name, price, category) VALUES (?, ?, ?)',
                (name, price, category)
            )
            print(f"✅ Добавлен: {name} - {price}₽ ({category})")
            added_count += 1
        except Exception as e:
            if "UNIQUE constraint" in str(e):
                print(f"⚠️  Уже существует: {name}")
            else:
                print(f"❌ Ошибка с {name}: {e}")

    db.conn.commit()
    print(f"\n🎯 Добавлено {added_count} новых позиций")


def repopulate_all_menu():
    """Полностью перезаполнить таблицу меню"""
    db = Database()
    cursor = db.conn.cursor()

    print("🔄 Полное обновление меню...")

    # Очищаем таблицу
    cursor.execute('DELETE FROM menu_items')
    print("✅ Таблица очищена")

    # Все позиции меню
    all_menu_items = [
        # Кальяны
        ('Пенсионный', 800, 'Кальяны'),
        ('Стандарт', 1000, 'Кальяны'),
        ('Премиум', 1200, 'Кальяны'),
        ('Фруктовая чаша', 1500, 'Кальяны'),
        ('Сигарный', 1500, 'Кальяны'),
        ('Парфюм', 2000, 'Кальяны'),

        # Напитки
        ('Вода', 100, 'Напитки'),
        ('Кола 0,5л', 100, 'Напитки'),
        ('Кола/Фанта/Спрайт 1л', 200, 'Напитки'),
        ('Пиво/Энергетик', 200, 'Напитки'),

        # Коктейли
        ('В/кола', 400, 'Коктейли'),
        ('Санрайз', 400, 'Коктейли'),
        ('Лагуна', 400, 'Коктейли'),
        ('Фиеро', 400, 'Коктейли'),
        ('Пробирки', 600, 'Коктейли'),

        # Чай
        ("Да Хун Пао", 400, "Чай"),
        ("Те Гуань Инь", 400, "Чай"),
        ("Шу пуэр", 400, "Чай"),
        ("Сяо Чжун", 400, "Чай"),
        ("Юэ Гуан Бай", 400, "Чай"),
        ("Габа", 400, "Чай"),
        ("Гречишный", 400, "Чай"),
        ("Медовая дыня", 400, "Чай"),
        ("Малина/Мята", 400, "Чай"),
        ("Наглый фрукт", 400, "Чай"),
        ("Вишневый пуэр", 500, "Чай"),
        ("Марокканский", 500, "Чай"),
        ("Голубика", 500, "Чай"),
        ("Смородиновый", 500, "Чай"),
        ("Клубничный", 500, "Чай"),
        ("Облепиховый", 500, "Чай")
    ]

    # Добавляем все позиции
    for name, price, category in all_menu_items:
        try:
            cursor.execute(
                'INSERT INTO menu_items (name, price, category) VALUES (?, ?, ?)',
                (name, price, category)
            )
        except Exception as e:
            print(f"❌ Ошибка с {name}: {e}")

    db.conn.commit()
    print(f"✅ Добавлено {len(all_menu_items)} позиций в меню")


if __name__ == "__main__":
    print("Выберите действие:")
    print("1 - Добавить только отсутствующие кальяны")
    print("2 - Полностью перезаполнить меню")

    choice = input("Введите 1 или 2: ")

    if choice == "1":
        add_missing_hookahs()
    elif choice == "2":
        repopulate_all_menu()
    else:
        print("❌ Неверный выбор")