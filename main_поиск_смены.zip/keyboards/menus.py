from telegram import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton


# Главное меню пользователя
def get_user_main_menu():
    keyboard = [
        [KeyboardButton("💰 Мой баланс")],
        [KeyboardButton("🎁 Списать баллы")],
        [KeyboardButton("📅 Забронировать стол"), KeyboardButton("📋 Мои бронирования")],
        [KeyboardButton("🎁 Реферальная программа"), KeyboardButton("📞 Контакты")],
        [KeyboardButton("⬅️ Назад")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)


# Клавиатура контактов
def get_contacts_keyboard():
    keyboard = [
        [KeyboardButton("📞 Позвонить"), KeyboardButton("💬 Написать в Telegram")],
        [KeyboardButton("📍 Мы на картах"), KeyboardButton("⬅️ Назад")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)


# Меню фильтрации бронирований для пользователя
def get_user_booking_filter_menu():
    keyboard = [
        [KeyboardButton("⏳ Ожидающие"), KeyboardButton("✅ Подтвержденные")],
        [KeyboardButton("❌ Отмененные"), KeyboardButton("📋 Все бронирования")],
        [KeyboardButton("⬅️ Назад")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)


# Клавиатура для отмены бронирования пользователем
def get_user_booking_cancel_keyboard(booking_id):
    keyboard = [
        [InlineKeyboardButton("❌ Отменить бронирование", callback_data=f"user_cancel_booking_{booking_id}")],
        [InlineKeyboardButton("⬅️ Назад к списку", callback_data="back_to_bookings_list")]
    ]
    return InlineKeyboardMarkup(keyboard)


# Главное меню администратора (ОБНОВЛЕНО: убрана кнопка "Написать пользователю")
def get_admin_main_menu():
    keyboard = [
        [KeyboardButton("👥 Список пользователей")],
        [KeyboardButton("📊 Статистика"), KeyboardButton("📢 Рассылка")],
        [KeyboardButton("📋 Запросы на списание"), KeyboardButton("📅 Бронирования")],
        [KeyboardButton("🍽️ Управление заказами"), KeyboardButton("🍴 Управление меню")],
        [KeyboardButton("⬅️ В главное меню")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)


# Меню управления меню для администратора
def get_menu_management_keyboard():
    keyboard = [
        [KeyboardButton("📋 Просмотр меню")],
        [KeyboardButton("➕ Добавить позицию"), KeyboardButton("✏️ Редактировать позицию")],
        [KeyboardButton("🗑️ Удалить позицию")],
        [KeyboardButton("⬅️ Назад в админ-панель")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)


# Меню фильтрации бронирований для администратора
def get_booking_filter_menu():
    keyboard = [
        [KeyboardButton("⏳ Ожидающие"), KeyboardButton("✅ Подтвержденные")],
        [KeyboardButton("❌ Отмененные"), KeyboardButton("📅 По дате")],
        [KeyboardButton("📋 Все бронирования"), KeyboardButton("⬅️ Назад")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)


# Клавиатура для выбора даты бронирования
def get_dates_keyboard(dates):
    keyboard = []
    row = []
    for i, date in enumerate(dates):
        row.append(KeyboardButton(date))
        if len(row) == 2 or i == len(dates) - 1:
            keyboard.append(row)
            row = []

    # Добавляем кнопку отмены
    if keyboard:
        keyboard.append([KeyboardButton("❌ Отмена")])
    else:
        keyboard = [[KeyboardButton("❌ Отмена")]]

    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)


# Клавиатура для выбора пользователя
def get_users_keyboard(users):
    keyboard = []
    for user in users:
        keyboard.append([InlineKeyboardButton(
            f"{user[2]} {user[3]} (ID: {user[0]})",
            callback_data=f"select_user_{user[0]}"
        )])
    return InlineKeyboardMarkup(keyboard)


# Клавиатура для действий с пользователем (ОСТАЕТСЯ КНОПКА "Написать")
def get_user_actions_keyboard(user_id):
    keyboard = [
        [
            InlineKeyboardButton("💰 Начислить 5%", callback_data=f"add_bonus_{user_id}"),
            InlineKeyboardButton("✉️ Написать", callback_data=f"message_{user_id}")
        ],
        [
            InlineKeyboardButton("📊 Списать баллы", callback_data=f"remove_bonus_{user_id}"),
            InlineKeyboardButton("👤 Информация", callback_data=f"info_{user_id}")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)


# Клавиатура для подтверждения запросов на списание
def get_bonus_request_keyboard(request_id):
    keyboard = [
        [
            InlineKeyboardButton("✅ Подтвердить", callback_data=f"approve_{request_id}"),
            InlineKeyboardButton("❌ Отклонить", callback_data=f"reject_{request_id}")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)


# Клавиатура для управления бронированиями администратором
def get_booking_actions_keyboard(booking_id):
    keyboard = [
        [
            InlineKeyboardButton("✅ Подтвердить", callback_data=f"confirm_booking_{booking_id}"),
            InlineKeyboardButton("❌ Отменить с причиной", callback_data=f"cancel_booking_reason_{booking_id}")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)


# Кнопка для отправки номера телефона
def get_phone_keyboard():
    keyboard = [[KeyboardButton("📱 Отправить номер телефона", request_contact=True)]]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)


# Клавиатура подтверждения
def get_confirmation_keyboard():
    keyboard = [
        [KeyboardButton("✅ Подтвердить"), KeyboardButton("✏️ Изменить данные")],
        [KeyboardButton("❌ Отмена")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)


# Клавиатура отмены
def get_cancel_keyboard():
    keyboard = [[KeyboardButton("❌ Отмена")]]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)


# Клавиатура для списания баллов
def get_spend_bonus_keyboard():
    keyboard = [
        [KeyboardButton("50 баллов"), KeyboardButton("100 баллов")],
        [KeyboardButton("200 баллов"), KeyboardButton("500 баллов")],
        [KeyboardButton("❌ Отмена")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)


# Клавиатура реферальной программы
def get_referral_keyboard():
    keyboard = [
        [KeyboardButton("📊 Моя статистика"), KeyboardButton("🔗 Получить ссылку")],
        [KeyboardButton("⬅️ Назад")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)


def get_bonus_requests_menu():
    """Меню для управления запросами на списание"""
    keyboard = [
        [KeyboardButton("🔄 Обновить список запросов")],
        [KeyboardButton("📊 Статистика"), KeyboardButton("📅 Бронирования")],
        [KeyboardButton("👥 Список пользователей"), KeyboardButton("📢 Рассылка")],
        [KeyboardButton("✉️ Написать пользователю"), KeyboardButton("⬅️ В главное меню")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)


# НОВЫЕ КЛАВИАТУРЫ ДЛЯ УПРАВЛЕНИЯ МЕНЮ

def get_categories_keyboard(categories):
    """Клавиатура для выбора категории меню"""
    keyboard = []
    row = []
    for i, category in enumerate(categories):
        row.append(InlineKeyboardButton(category, callback_data=f"menu_category_{category}"))
        if len(row) == 2 or i == len(categories) - 1:
            keyboard.append(row)
            row = []
    keyboard.append([InlineKeyboardButton("⬅️ Назад", callback_data="back_to_menu_management")])
    return InlineKeyboardMarkup(keyboard)


def get_menu_items_keyboard(items, action_prefix):
    """Клавиатура для выбора позиций меню"""
    keyboard = []
    for item in items:
        keyboard.append([
            InlineKeyboardButton(
                f"{item[1]} - {item[2]}₽",
                callback_data=f"{action_prefix}_{item[0]}"
            )
        ])
    keyboard.append([InlineKeyboardButton("⬅️ Назад к категориям", callback_data="back_to_categories_list")])
    return InlineKeyboardMarkup(keyboard)


def get_menu_item_actions_keyboard(item_id):
    """Клавиатура действий с позицией меню"""
    keyboard = [
        [
            InlineKeyboardButton("✏️ Изменить название", callback_data=f"edit_name_{item_id}"),
            InlineKeyboardButton("💰 Изменить цену", callback_data=f"edit_price_{item_id}")
        ],
        [InlineKeyboardButton("⬅️ Назад к списку", callback_data="back_to_categories_list")]
    ]
    return InlineKeyboardMarkup(keyboard)


def get_edit_confirmation_keyboard(item_id):
    """Клавиатура подтверждения удаления"""
    keyboard = [
        [
            InlineKeyboardButton("✅ Да, удалить", callback_data=f"confirm_delete_{item_id}"),
            InlineKeyboardButton("❌ Нет, отменить", callback_data=f"cancel_delete_{item_id}")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)


def get_back_to_menu_management_keyboard():
    """Клавиатура для возврата в управление меню"""
    keyboard = [[InlineKeyboardButton("⬅️ Назад в управление меню", callback_data="back_to_menu_management")]]
    return InlineKeyboardMarkup(keyboard)