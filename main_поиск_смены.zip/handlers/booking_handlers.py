from telegram import Update
from telegram.ext import ContextTypes, ConversationHandler, MessageHandler, filters, CommandHandler, \
    CallbackQueryHandler
from database import Database
from keyboards.menus import get_user_main_menu, get_cancel_keyboard
from config import ADMIN_IDS
from message_manager import message_manager
import logging

logger = logging.getLogger(__name__)

db = Database()

# Состояния для бронирования
BOOKING_DATE, BOOKING_TIME, BOOKING_GUESTS = range(3)


async def start_booking(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # ПОЛНАЯ ОЧИСТКА при начале бронирования
    await message_manager.cleanup_all_messages(context, update.effective_user.id)

    user = update.effective_user
    user_data = db.get_user(user.id)

    if not user_data:
        await message_manager.send_message(
            update, context,
            "❌ Сначала зарегистрируйтесь с помощью /start",
            is_temporary=True
        )
        return ConversationHandler.END

    await message_manager.send_message(
        update, context,
        "📅 Бронирование стола\n\n"
        "Введите дату бронирования (в формате ДД.ММ.ГГГГ):",
        reply_markup=get_cancel_keyboard(),
        is_temporary=False
    )
    return BOOKING_DATE


async def get_booking_date(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.text == "❌ Отмена":
        await message_manager.cleanup_all_messages(context, update.effective_user.id)
        await message_manager.send_message(
            update, context,
            "❌ Бронирование отменено.",
            reply_markup=get_user_main_menu(),
            is_temporary=False
        )
        return ConversationHandler.END

    date = update.message.text.strip()

    # Простая валидация даты
    try:
        day, month, year = map(int, date.split('.'))
        context.user_data['booking_date'] = date
        await message_manager.send_message(
            update, context,
            "Введите время бронирования (в формате ЧЧ:ММ):",
            is_temporary=False
        )
        return BOOKING_TIME
    except:
        await message_manager.send_message(
            update, context,
            "❌ Неверный формат даты. Используйте ДД.ММ.ГГГГ:",
            is_temporary=True
        )
        return BOOKING_DATE


async def get_booking_time(update: Update, context: ContextTypes.DEFAULT_TYPE):
    time = update.message.text.strip()

    # Простая валидация времени
    try:
        hours, minutes = map(int, time.split(':'))
        if 0 <= hours < 24 and 0 <= minutes < 60:
            context.user_data['booking_time'] = time
            await message_manager.send_message(
                update, context,
                "Введите количество гостей:",
                is_temporary=False
            )
            return BOOKING_GUESTS
        else:
            raise ValueError
    except:
        await message_manager.send_message(
            update, context,
            "❌ Неверный формат времени. Используйте ЧЧ:ММ:",
            is_temporary=True
        )
        return BOOKING_TIME


async def get_booking_guests(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        guests = int(update.message.text.strip())

        if guests <= 0 or guests > 20:
            await message_manager.send_message(
                update, context,
                "❌ Количество гостей должно быть от 1 до 20:",
                is_temporary=True
            )
            return BOOKING_GUESTS

        user = update.effective_user
        user_data = db.get_user(user.id)

        # Создаем бронирование
        booking_id = db.create_booking(
            user_data[0],
            context.user_data['booking_date'],
            context.user_data['booking_time'],
            guests
        )

        # Отправляем уведомление администраторам - ИЗМЕНЕНИЕ ЗДЕСЬ
        for admin_id in ADMIN_IDS:
            try:
                await message_manager.send_message_to_chat(
                    context, admin_id,
                    f"📅 Новое бронирование!\n\n"
                    f"👤 Пользователь: {user_data[2]} {user_data[3]}\n"
                    f"📱 Телефон: {user_data[4]}\n"
                    f"📅 Дата: {context.user_data['booking_date']}\n"
                    f"⏰ Время: {context.user_data['booking_time']}\n"
                    f"👥 Гостей: {guests}\n"
                    f"🆔 ID брони: {booking_id}",
                    is_temporary=False  # ИЗМЕНЕНО: теперь постоянное сообщение
                )
            except Exception as e:
                logger.error(f"Не удалось отправить уведомление администратору {admin_id}: {e}")

        await message_manager.send_message(
            update, context,
            f"✅ Бронирование создано!\n\n"
            f"📅 Дата: {context.user_data['booking_date']}\n"
            f"⏰ Время: {context.user_data['booking_time']}\n"
            f"👥 Гостей: {guests}\n\n"
            f"Мы ждем вас! Ожидайте подтверждения от администратора.",
            reply_markup=get_user_main_menu(),
            is_temporary=False
        )

        context.user_data.clear()
        return ConversationHandler.END

    except ValueError:
        await message_manager.send_message(
            update, context,
            "❌ Пожалуйста, введите корректное число гостей:",
            is_temporary=True
        )
        return BOOKING_GUESTS


async def cancel_booking_conversation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await message_manager.cleanup_all_messages(context, update.effective_user.id)
    context.user_data.clear()
    await message_manager.send_message(
        update, context,
        "❌ Бронирование отменено.",
        reply_markup=get_user_main_menu(),
        is_temporary=False
    )
    return ConversationHandler.END


def get_booking_handler():
    return ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^📅 Забронировать стол$"), start_booking)],
        states={
            BOOKING_DATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_booking_date)],
            BOOKING_TIME: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_booking_time)],
            BOOKING_GUESTS: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_booking_guests)]
        },
        fallbacks=[
            MessageHandler(filters.Regex("^❌ Отмена$"), cancel_booking_conversation),
            CommandHandler('cancel', cancel_booking_conversation)
        ]
    )